
const { app, BrowserWindow, nativeTheme, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs'); // Use standard fs for synchronous operations

// Store data in the standard user data directory for the app
const dataFilePath = path.join(app.getPath('userData'), 'canteen-pos-data.json');

/**
 * Reads the application state from the JSON data file.
 * @returns {Promise<object|null>} The parsed state object, or null if not found or invalid.
 */
async function readData() {
    try {
        const fileContent = fs.readFileSync(dataFilePath, 'utf-8');
        return JSON.parse(fileContent);
    } catch (error) {
        // If file doesn't exist or is invalid, it's not a critical error.
        // The app will start with a default state. The renderer will handle this.
        return null;
    }
}

/**
 * Synchronously writes the application state to the JSON data file.
 * @param {object} data The application state object.
 */
function writeDataSync(data) {
    try {
        // Stringify with pretty printing for easier debugging of the data file.
        const dataStr = JSON.stringify(data, null, 2); 
        fs.writeFileSync(dataFilePath, dataStr, 'utf-8');
    } catch (error) {
        console.error('Failed to save data file synchronously:', error);
    }
}

function createWindow() {
  const mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 940,
    minHeight: 600,
    show: false, // Don't show the window until it's ready
    backgroundColor: '#ecf0f1', // Match the app's background color from CSS
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    title: "Canteen POS",
    autoHideMenuBar: true
  });

  // Load the index.html of the app using an absolute path.
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  
  // Show the window gracefully when the page is ready to prevent a white flash
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });


  // Set theme to match the app's light theme
  nativeTheme.themeSource = 'light';
}

// --- IPC HANDLERS ---

// IPC handler to load app state on startup
ipcMain.handle('data:load', async () => {
    return await readData();
});

// Synchronous IPC handler to save app state just before closing.
// This is critical to prevent data loss.
ipcMain.on('data:save-sync', (event, state) => {
    writeDataSync(state);
    // CRITICAL: Set returnValue to acknowledge the synchronous call.
    // This ensures the renderer process waits for the save to complete before closing.
    event.returnValue = true;
});


app.whenReady().then(() => {
  createWindow();

  app.on('activate', function () {
    // On macOS it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', function () {
  // Quit when all windows are closed, except on macOS.
  if (process.platform !== 'darwin') app.quit();
});