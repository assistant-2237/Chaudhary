
// All of the Node.js APIs are available in the preload process.
// It has the same sandbox as a Chrome extension.
const { contextBridge, ipcRenderer } = require('electron');

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object.
contextBridge.exposeInMainWorld('electronAPI', {
  // Asynchronous API to load data on startup
  loadData: () => ipcRenderer.invoke('data:load'),
  
  // Synchronous API to save data on exit. This is crucial for data integrity.
  saveDataSync: (state) => ipcRenderer.sendSync('data:save-sync', state),
});
