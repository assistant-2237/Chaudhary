

declare global {
  interface Window {
    // Expose Electron APIs to the renderer process
    electronAPI: {
      loadData: () => Promise<AppState | null>;
      saveDataSync: (state: AppState) => void;
    }
  }
}

import React, { useState, useEffect, createContext, useContext, useMemo, useCallback, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import QRCode from 'qrcode';

// --- DATA INTERFACES ---
interface BusinessInfo {
  name: string;
  address?: string;
  logo: string; // base64
  paymentNumber?: string;
  customQRImage?: string; // base64
}

interface Customer {
  id: string;
  name: string;
  mobile: string;
  address: string;
}

interface Employee {
  id: string;
  name: string;
  mobile: string;
  address: string;
  designation: string;
  joiningDate: string;
  salary: number;
  photo: string; // base64
}

interface Product {
  id: string;
  name: string;
  category: string;
  purchaseRate: number;
  saleRate: number;
  stock: number;
  image: string; // base64
  unit: string;
}

interface SaleItem {
  productId: string;
  quantity: number;
  saleRate: number;
  purchaseRate: number;
}

interface InvoicePayment {
    date: string;
    amount: number;
}

interface Invoice {
  id:string;
  date: string;
  customerId?: string;
  items: SaleItem[];
  subTotal: number;
  discount: number;
  finalAmount: number;
  payments: InvoicePayment[];
}

interface PurchaseItem {
    productId: string;
    quantity: number;
    purchaseRate: number;
}

interface Purchase {
  id: string;
  date: string;
  supplier?: string;
  invoiceNumber?: string;
  items: PurchaseItem[];
  totalAmount: number;
  notes?: string;
}


interface ExpenseItem {
    productId: string;
    quantity: number;
    purchaseRate: number;
}

interface Expense {
  id: string;
  title: string;
  amount: number;
  category: string;
  date: string;
  employeeId?: string;
  expenseType: 'General' | 'CanteenUsage' | 'Salary';
  items?: ExpenseItem[];
}

interface AppState {
  businessInfo: BusinessInfo;
  customers: Customer[];
  employees: Employee[];
  products: Product[];
  invoices: Invoice[];
  purchases: Purchase[];
  expenses: Expense[];
  expenseCategories: string[];
}

// --- APP CONTEXT ---
interface AppContextType {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
  activePage: string;
  setActivePage: React.Dispatch<React.SetStateAction<string>>;
  formatCurrency: (amount: number) => string;
}
const AppContext = createContext<AppContextType | null>(null);

const WALK_IN_CUSTOMER: Customer = { id: 'walk-in', name: 'Walk-in Customer', mobile: '', address: '' };

// --- CONSTANTS FOR PAKISTANI CONTEXT ---
const PAKISTANI_UNITS = ['Piece', 'Plate', 'Dozen', 'Kg', 'Gm', 'Litre', 'M.Litre', 'Cup', 'Bowl', 'Packet', 'Bottle'];
const PAKISTANI_FOOD_SUGGESTIONS = [
    { id: 'Biryani', name: 'Biryani' },
    { id: 'Chicken Biryani', name: 'Chicken Biryani' },
    { id: 'Beef Biryani', name: 'Beef Biryani' },
    { id: 'Karahi', name: 'Karahi' },
    { id: 'Chicken Karahi', name: 'Chicken Karahi' },
    { id: 'Mutton Karahi', name: 'Mutton Karahi' },
    { id: 'Qorma', name: 'Qorma' },
    { id: 'Samosa', name: 'Samosa' },
    { id: 'Aloo Samosa', name: 'Aloo Samosa' },
    { id: 'Keema Samosa', name: 'Keema Samosa' },
    { id: 'Pakora', name: 'Pakora' },
    { id: 'Naan', name: 'Naan' },
    { id: 'Roghni Naan', name: 'Roghni Naan' },
    { id: 'Garlic Naan', name: 'Garlic Naan' },
    { id: 'Roti', name: 'Roti' },
    { id: 'Tandoori Roti', name: 'Tandoori Roti' },
    { id: 'Paratha', name: 'Paratha' },
    { id: 'Aloo Paratha', name: 'Aloo Paratha' },
    { id: 'Seekh Kebab', name: 'Seekh Kebab' },
    { id: 'Haleem', name: 'Haleem' },
    { id: 'Nihari', name: 'Nihari' },
    { id: 'Pulao', name: 'Pulao' },
    { id: 'Chicken Pulao', name: 'Chicken Pulao' },
    { id: 'Tikka', name: 'Tikka' },
    { id: 'Chicken Tikka', name: 'Chicken Tikka' },
    { id: 'Chai', name: 'Chai' },
    { id: 'Doodh Patti', name: 'Doodh Patti' },
    { id: 'Lassi', name: 'Lassi' },
    { id: 'Jalebi', name: 'Jalebi' },
    { id: 'Gulab Jamun', name: 'Gulab Jamun' },
    { id: 'Kheer', name: 'Kheer' },
    { id: 'Zarda', name: 'Zarda' },
    { id: 'French Fries', name: 'French Fries' },
    { id: 'Shami Burger', name: 'Shami Burger' },
    { id: 'Zinger Burger', name: 'Zinger Burger' },
    { id: 'Shawarma', name: 'Shawarma' },
    { id: 'Cold Drink', name: 'Cold Drink' },
    { id: 'Water Bottle', name: 'Water Bottle' },
].map(item => ({...item, id: item.name}));


// --- UTILITY FUNCTIONS ---
const toBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
});

const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString();

const formatCurrency = (amount: number) => {
    try {
        return new Intl.NumberFormat('en-PK', {
            style: 'currency',
            currency: 'PKR',
        }).format(amount);
    } catch (e) {
        console.error("Currency formatting error:", e);
        return `PKR ${amount.toFixed(2)}`;
    }
};

const generateQR = async (text: string): Promise<string> => {
    try {
        return await QRCode.toDataURL(text, { width: 100, margin: 1 });
    } catch (err) {
        console.error("Failed to generate QR code", err);
        return '';
    }
};

const getInvoicePaymentInfo = (invoice: Invoice) => {
    const amountReceived = (invoice.payments || []).reduce((sum, p) => sum + p.amount, 0);
    const finalAmount = invoice.finalAmount || 0;
    const balanceDue = finalAmount - amountReceived;

    const getStatusInfo = (): {text: string, className: string} => {
        if (balanceDue <= 0.01) return { text: 'Paid', className: 'status-paid' };
        if (amountReceived > 0) return { text: 'Partial', className: 'status-partial' };
        return { text: 'Unpaid', className: 'status-unpaid' };
    };

    return { amountReceived, balanceDue, status: getStatusInfo() };
};

const getCustomerBalance = (customerId: string, allInvoices: Invoice[]): number => {
    if (!customerId) return 0;
    const customerInvoices = allInvoices.filter(inv => inv.customerId === customerId);
    const totalBalance = customerInvoices.reduce((sum, inv) => {
        const { balanceDue } = getInvoicePaymentInfo(inv);
        return sum + balanceDue;
    }, 0);
    return totalBalance;
};


const getReceiptStyles = () => `
    @import url('https://fonts.googleapis.com/css2?family=Cutive+Mono&display=swap');
    
    body { 
        font-family: 'Cutive Mono', monospace; 
        margin: 0; 
        background-color: #ccc;
    }
    .receipt {
        width: 72mm;
        max-width: 72mm;
        margin: 15px auto;
        background: #fff;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        padding: 15px;
        font-size: 12px;
        line-height: 1.4;
        color: #000;
    }
    
    .receipt-header, .receipt-footer {
        text-align: center;
    }
    
    .receipt-header {
        padding-bottom: 10px;
        margin-bottom: 10px;
        border-bottom: 1px dashed #000;
    }
    
    .receipt-logo {
        max-width: 45px;
        max-height: 45px;
        width: auto;
        height: auto;
        object-fit: contain;
        margin-bottom: 5px;
    }
    
    .business-name {
        font-size: 16px;
        font-weight: bold;
        margin: 0;
    }
    
    .business-address {
        font-size: 11px;
        margin: 4px 0 0 0;
        line-height: 1.3;
    }

    .invoice-details p, .items-table p, .totals-section p, .payment-details p {
        margin: 0;
    }
    
    .invoice-details {
        margin-bottom: 10px;
    }

    .items-table { 
        width: 100%; 
        border-collapse: collapse; 
    }
    
    .items-table thead th { 
        text-align: left; 
        padding-bottom: 5px; 
        border-top: 1px dashed #000;
        border-bottom: 1px dashed #000;
        font-size: 11px; 
        font-weight: bold;
        text-transform: uppercase;
    }
    
    .items-table .col-right { 
        text-align: right; 
    }
    
    .items-table tbody tr td { 
        padding: 6px 0; 
        border-bottom: 1px dotted #888;
        vertical-align: top; 
    }
    
    .item-name { 
        display: block;
        font-size: 13px;
    }
    .item-qty-rate { 
        font-size: 11px; 
        color: #444;
    }

    .totals-section, .payment-details { 
        margin-top: 10px; 
        padding-top: 5px;
        border-top: 1px dashed #000;
    }

    .summary-row {
        display: flex; 
        justify-content: space-between; 
        padding: 2px 0;
    }
    
    .grand-total { 
        font-size: 18px; 
        font-weight: bold;
        margin-top: 5px;
    }
    
    .payment-status {
        font-weight: bold;
    }
    
    .receipt-footer {
        margin-top: 15px;
        padding-top: 10px;
        border-top: 1px dashed #000;
        font-size: 11px;
    }
    
    .qr-code { 
        width: 65px;
        height: 65px; 
        margin: 10px auto; 
    }
    .qr-code img { 
        width: 100%; 
        height: 100%; 
        object-fit: contain; 
    }
`;

const printReceipt = async (invoice: Invoice, businessInfo: BusinessInfo, products: Product[], customers: Customer[]) => {
    const customer = customers.find(c => c.id === invoice.customerId);
    const { amountReceived, balanceDue, status } = getInvoicePaymentInfo(invoice);
    
    let qrCodeUrl = '';
    if (businessInfo.customQRImage) {
        qrCodeUrl = businessInfo.customQRImage;
    } else if (businessInfo.paymentNumber) {
        qrCodeUrl = await generateQR(businessInfo.paymentNumber);
    }

    const receiptContent = `
        <div class="receipt">
            <header class="receipt-header">
                ${businessInfo.logo ? `<img src="${businessInfo.logo}" alt="Logo" class="receipt-logo"/>` : ''}
                <p class="business-name">${businessInfo.name || 'Canteen POS'}</p>
            </header>
            
            <section class="invoice-details">
                <p>Invoice #: ${invoice.id}</p>
                <p>Date: ${new Date(invoice.date).toLocaleString()}</p>
                <p>Customer: ${customer ? customer.name : 'Walk-in Customer'}</p>
                ${customer && customer.mobile ? `<p>Mobile: ${customer.mobile}</p>` : ''}
            </section>

            <table class="items-table">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th class="col-right">Total</th>
                    </tr>
                </thead>
                <tbody>
                    ${invoice.items.map(item => {
                        const product = products.find(p => p.id === item.productId);
                        return `<tr>
                            <td>
                                <span class="item-name">${product?.name || 'N/A'}</span>
                                <span class="item-qty-rate">${item.quantity} ${product?.unit || ''} &times; ${formatCurrency(item.saleRate)}</span>
                            </td>
                            <td class="col-right">${formatCurrency(item.quantity * item.saleRate)}</td>
                        </tr>`;
                    }).join('')}
                </tbody>
            </table>

            <section class="totals-section">
                <p class="summary-row">
                    <span>Subtotal</span>
                    <span>${formatCurrency(invoice.subTotal)}</span>
                </p>
                <p class="summary-row">
                    <span>Discount</span>
                    <span>-${formatCurrency(invoice.discount)}</span>
                </p>
                <p class="summary-row grand-total">
                    <span>TOTAL</span>
                    <span>${formatCurrency(invoice.finalAmount)}</span>
                </p>
            </section>

            <section class="payment-details">
                 <p class="summary-row">
                    <span>Amount Paid</span>
                    <span>${formatCurrency(amountReceived)}</span>
                </p>
                 <p class="summary-row">
                    <span>Balance Due</span>
                    <span>${formatCurrency(balanceDue)}</span>
                </p>
                 <p class="summary-row">
                    <span>Status</span>
                    <span class="payment-status">${status.text}</span>
                </p>
            </section>

            <footer class="receipt-footer">
                <p>Thank you for your business!</p>
                ${businessInfo.address ? `<p class="business-address">${businessInfo.address.replace(/\n/g, '<br>')}</p>` : ''}
                ${qrCodeUrl ? `
                    <div class="qr-code">
                        <img src="${qrCodeUrl}" alt="Payment QR Code" />
                    </div>` : ''
                }
                ${businessInfo.paymentNumber ? `<p>Scan or pay at: ${businessInfo.paymentNumber}</p>` : ''}
            </footer>
        </div>
    `;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
        printWindow.document.write(`<html><head><title>Print Receipt - ${invoice.id}</title><style>${getReceiptStyles()}</style></head><body>${receiptContent}</body></html>`);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
        }, 250);
    }
};

const getReportStyles = () => `
    body { font-family: 'Poppins', sans-serif; margin: 20px; color: #34495e; }
    @page { size: A4; margin: 20mm; }
    .report-logo { display: block; margin: 0 auto 15px auto; max-height: 70px; max-width: 250px; object-fit: contain; }
    h1, h2, h3 { color: #2c3e50; text-align: center; }
    h1 { font-size: 24px; margin-bottom: 5px; }
    h2 { font-size: 16px; font-weight: normal; color: #7f8c8d; margin-bottom: 30px; }
    .report-content { border-top: 2px solid #34495e; padding-top: 20px; }
    table { width: 100%; border-collapse: collapse; margin-top: 15px; }
    th, td { padding: 8px 12px; border: 1px solid #bdc3c7; text-align: left; font-size: 12px; }
    th { background-color: #f2f2f2; font-weight: 600; }
    td { vertical-align: top; }
    tfoot tr { background-color: #e9ecef; font-weight: bold;}
    tfoot td { border-top: 2px solid #34495e; }
    p { margin: 8px 0; font-size: 14px; }
    strong { font-weight: 600; }
    ul { padding-left: 20px; margin-top: 5px; }
    li { margin-bottom: 5px; }
    hr { border: 0; border-top: 1px solid #bdc3c7; }
    .report-section { margin-bottom: 25px; }
    .report-section h3 { font-size: 18px; padding-bottom: 10px; border-bottom: 1px solid #bdc3c7; margin-bottom: 15px; text-align: left; }
    .report-summary-grid { display: none; }
    .summary-box { background: #f8f9fa; border: 1px solid #e9ecef; padding: 15px; border-radius: 8px; text-align: center; }
    .summary-box-label { font-size: 13px; color: #7f8c8d; margin-bottom: 8px; display: block; }
    .summary-box-value { font-size: 22px; font-weight: 600; }
    .profit { color: #27ae60; }
    .loss { color: #e74c3c; }
    .receivables-customer-row { background-color: #f8f9fa; font-weight: bold; }
    .receivables-invoice-row td { padding-left: 30px; font-size: 11px; }
`;

const printReport = (title: string, contentEl: HTMLElement | null, businessInfo: BusinessInfo) => {
    if (!contentEl) {
        alert("Could not find report content to print.");
        return;
    }
    
    const printContent = contentEl.innerHTML;
    
    const reportHtml = `
        <html>
            <head>
                <title>${title}</title>
                 <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
                <style>${getReportStyles()}</style>
            </head>
            <body>
                ${businessInfo.logo ? `<img src="${businessInfo.logo}" alt="Logo" class="report-logo"/>` : ''}
                <h1>${businessInfo.name || 'Canteen POS'}</h1>
                <h2>${title}</h2>
                <div class="report-content">
                    ${printContent}
                </div>
            </body>
        </html>
    `;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
        printWindow.document.write(reportHtml);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
        }, 250);
    }
};

// --- HOOKS ---
const useAppContext = () => {
    const context = useContext(AppContext);
    if (!context) throw new Error("useAppContext must be used within an AppProvider");
    return context;
};

// --- HELPER COMPONENTS ---
const Modal: React.FC<{ title: string; onClose: () => void; children: React.ReactNode }> = ({ title, onClose, children }) => (
    <div className="modal-overlay" onClick={onClose}>
        <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
                <h2>{title}</h2>
                <button onClick={onClose} className="btn btn-icon">&times;</button>
            </div>
            <div className="modal-body">{children}</div>
        </div>
    </div>
);

const StatCard: React.FC<{ icon: string; label: string; value: string | number; color: string; children?: React.ReactNode }> = ({ icon, label, value, color, children }) => (
    <div className="card stat-card">
        <div className="stat-card-icon" style={{ backgroundColor: color }}>{icon}</div>
        <div className="stat-card-info">
            <h3>{label}</h3>
            <p>{value}</p>
        </div>
        {children}
    </div>
);

const NeonClock = () => {
    const [time, setTime] = useState(new Date());
    useEffect(() => {
        const timerId = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timerId);
    }, []);
    return (
        <div className="neon-clock-card">
            <div className="neon-clock">
                {time.toLocaleTimeString('en-US', { hour12: true })}
            </div>
        </div>
    );
};

const SearchableSelect = <T extends { id: string; name: string }>({
    options,
    value,
    onChange,
    placeholder,
    onAddNew,
    disabled = false
}: {
    options: T[];
    value: T | null;
    onChange: (selected: T | null) => void;
    placeholder: string;
    onAddNew?: () => void;
    disabled?: boolean;
}) => {
    const [isOpen, setIsOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const wrapperRef = useRef<HTMLDivElement>(null);

    const filteredOptions = useMemo(() =>
        options.filter(option =>
            option.name.toLowerCase().includes(searchTerm.toLowerCase())
        ), [options, searchTerm]);

    const handleSelect = (option: T) => {
        onChange(option);
        setSearchTerm("");
        setIsOpen(false);
    };

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
                setIsOpen(false);
                setSearchTerm(""); // Clear search on closing
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);
    
    if (value && !isOpen) {
        return (
            <div className={`searchable-select ${disabled ? 'disabled' : ''}`}>
                <div className={`selected-option ${disabled ? 'disabled' : ''}`} onClick={() => !disabled && setIsOpen(true)}>
                    <span>{value.name}</span>
                    {!disabled && (
                        <button className="clear-btn" onClick={(e) => { e.stopPropagation(); onChange(null); }}>&times;</button>
                    )}
                </div>
            </div>
        );
    }
    
    return (
        <div className="searchable-select" ref={wrapperRef}>
            <input
                type="text"
                placeholder={placeholder}
                value={searchTerm}
                onChange={e => {
                   setSearchTerm(e.target.value);
                }}
                onFocus={() => setIsOpen(true)}
                disabled={disabled}
                autoFocus={isOpen}
            />
            {isOpen && (
                <ul className="options-list">
                    {filteredOptions.length > 0 ? (
                        filteredOptions.map(option => (
                            <li key={option.id} onClick={() => handleSelect(option)}>
                                {option.name}
                            </li>
                        ))
                    ) : (
                       <li className="no-options">No options found</li>
                    )}
                    {onAddNew && (
                        <li className="no-options info" onClick={() => { setIsOpen(false); onAddNew(); }}>
                           Not found? Click to add a new one.
                        </li>
                    )}
                </ul>
            )}
        </div>
    );
};

const ImageUpload: React.FC<{
    currentImage: string;
    onImageChange: (base64: string) => void;
    label: string;
}> = ({ currentImage, onImageChange, label }) => {
    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const base64 = await toBase64(e.target.files[0]);
            onImageChange(base64);
        }
    };

    return (
        <div className="form-group">
            <label>{label}</label>
            {currentImage && <img src={currentImage} alt="Preview" className="product-image-thumb" style={{ marginBottom: '10px', display: 'block' }} />}
            <input type="file" accept="image/*" onChange={handleFileChange} />
        </div>
    );
};

const NavItem: React.FC<{ icon: string; text: string; page: string; }> = ({ icon, text, page }) => {
    const { activePage, setActivePage } = useAppContext();
    return (
        <li>
            <button className={activePage === page ? 'active' : ''} onClick={() => setActivePage(page)}>
                <span className="nav-icon">{icon}</span>
                <span>{text}</span>
            </button>
        </li>
    );
};

// --- DATA MIGRATION ---
const migrateInvoices = (data: any): AppState => {
    if (!data.invoices) {
        return data; // Not an old structure or no invoices
    }

    const needsMigration = data.invoices.some((inv: any) => inv.amountReceived !== undefined && inv.payments === undefined);

    if (needsMigration) {
        console.log("Old invoice data structure detected. Migrating invoices...");
        const migratedInvoices = data.invoices.map((inv: any) => {
            if (inv.amountReceived !== undefined && inv.payments === undefined) {
                const newPayments: InvoicePayment[] = [];
                if (inv.amountReceived > 0) {
                    newPayments.push({ date: inv.date, amount: inv.amountReceived });
                }
                const { amountReceived, ...restOfInv } = inv;
                return { ...restOfInv, payments: newPayments };
            }
            return inv;
        });
        return { ...data, invoices: migratedInvoices };
    }
    
    return data as AppState;
};

const migratePurchases = (data: AppState): AppState => {
    if (!data.purchases || data.purchases.length === 0) {
        return data;
    }

    const needsMigration = data.purchases.some(p => (p as any).productId !== undefined);

    if (needsMigration) {
        console.log("Old purchase data structure detected. Migrating purchases...");
        const migratedPurchases = (data.purchases as any[]).map(oldPurchase => {
            if (oldPurchase.productId !== undefined) {
                const newItem: PurchaseItem = {
                    productId: oldPurchase.productId,
                    quantity: oldPurchase.quantity,
                    purchaseRate: oldPurchase.purchaseRate,
                };
                const newPurchase: Purchase = {
                    id: oldPurchase.id,
                    date: oldPurchase.date,
                    supplier: oldPurchase.supplier,
                    notes: oldPurchase.notes,
                    items: [newItem],
                    totalAmount: (newItem.quantity || 0) * (newItem.purchaseRate || 0),
                };
                return newPurchase;
            }
            return oldPurchase;
        }).filter(p => p.items && p.items.length > 0);
        
        return { ...data, purchases: migratedPurchases as Purchase[] };
    }

    return data;
};

// --- PAGES ---

// Developer Credit Component
const DeveloperCredit = () => (
    <div className="developer-credit-card">
        <p style={{ fontWeight: 600, fontSize: '1.1rem' }}>Developed by Mr Nadeem Chaudhary</p>
        <p>Mobile: 03435601381 | Email: assistant2237@gmail.com | WhatsApp: 03435601381</p>
    </div>
);

// Dashboard Page
const Dashboard: React.FC = () => {
    const { state, setActivePage, formatCurrency } = useAppContext();
    const { businessInfo, invoices, products, customers, expenses } = state;
    
    const stats = useMemo(() => {
        const today = new Date().toISOString().split('T')[0];
        const todaysInvoices = invoices.filter(inv => inv.date.startsWith(today));
        const todaysSales = todaysInvoices.reduce((sum, inv) => sum + inv.finalAmount, 0);
        
        const todaysPayments = invoices.flatMap(inv => inv.payments || [])
            .filter(p => p.date.startsWith(today))
            .reduce((sum, p) => sum + p.amount, 0);

        const totalReceivable = invoices
            .map(inv => ({ ...inv, paymentInfo: getInvoicePaymentInfo(inv) }))
            .reduce((sum, inv) => sum + inv.paymentInfo.balanceDue, 0);

        const lowStockProducts = products.filter(p => p.stock > 0 && p.stock <= 5).length;
        
        return { todaysSales, todaysPayments, totalReceivable, lowStockProducts };
    }, [invoices, products]);

    const recentActivity = useMemo(() => {
        const sortedInvoices = [...invoices].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        return sortedInvoices.slice(0, 5);
    }, [invoices]);

    const topSellingProducts = useMemo(() => {
        const productSales = new Map<string, number>();
        invoices.forEach(invoice => {
            invoice.items.forEach(item => {
                const currentQty = productSales.get(item.productId) || 0;
                productSales.set(item.productId, currentQty + item.quantity);
            });
        });

        const sortedProducts = Array.from(productSales.entries())
            .sort(([, qtyA], [, qtyB]) => qtyB - qtyA)
            .slice(0, 5);

        return sortedProducts.map(([productId, quantitySold]) => {
            const product = products.find(p => p.id === productId);
            return { product, quantitySold };
        }).filter(item => item.product);
    }, [invoices, products]);

    return (
        <div>
            <div className="dashboard-welcome">
                 <h1>Welcome, {businessInfo.name || 'Admin'}!</h1>
                 <p>Here's a summary of your canteen's activity.</p>
            </div>

            <NeonClock />
            
            <div className="dashboard-grid">
                <StatCard icon="💰" label="Today's Sales" value={formatCurrency(stats.todaysSales)} color="#3498db" />
                <StatCard icon="💵" label="Daily Cash Received" value={formatCurrency(stats.todaysPayments)} color="#2ecc71" />
                <StatCard icon="🏦" label="Total Receivable" value={formatCurrency(stats.totalReceivable)} color="#f39c12" />
                <StatCard icon="📦" label="Low Stock Items" value={stats.lowStockProducts} color="#e74c3c">
                  {stats.lowStockProducts > 0 && <button className="btn btn-primary" onClick={() => setActivePage('products')}>View</button>}
                </StatCard>
            </div>
            
             <div className="card">
                <h3 className="card-header-title">Quick Actions</h3>
                <div className="quick-actions-grid">
                    <div className="action-button" onClick={() => setActivePage('newSale')}>
                        <div className="action-button-icon">🛒</div>
                        <div className="action-button-label">New Sale</div>
                    </div>
                    <div className="action-button" onClick={() => setActivePage('invoices')}>
                        <div className="action-button-icon">🧾</div>
                        <div className="action-button-label">View Invoices</div>
                    </div>
                     <div className="action-button" onClick={() => setActivePage('products')}>
                        <div className="action-button-icon">🍔</div>
                        <div className="action-button-label">Manage Products</div>
                    </div>
                    <div className="action-button" onClick={() => setActivePage('expenses')}>
                        <div className="action-button-icon">💸</div>
                        <div className="action-button-label">Add Expense</div>
                    </div>
                </div>
            </div>

            <div className="dashboard-columns">
                <div className="card activity-card">
                    <h3 className="card-header-title">Recent Sales</h3>
                    {recentActivity.length > 0 ? (
                        <ul className="activity-list">
                            {recentActivity.map(invoice => {
                                const customer = customers.find(c => c.id === invoice.customerId);
                                const paymentInfo = getInvoicePaymentInfo(invoice);
                                return (
                                    <li key={invoice.id}>
                                        <div className="activity-item">
                                            <span><strong>{customer?.name || 'Walk-in'}</strong> bought {invoice.items.length} item(s)</span>
                                            <strong>{formatCurrency(invoice.finalAmount)}</strong>
                                        </div>
                                        <div className="activity-meta">
                                            <span>Invoice: <a href="#" onClick={(e) => { e.preventDefault(); /* a modal can be shown here */ }}>{invoice.id}</a></span>
                                            <span>
                                                Status: <span className={`status-badge ${paymentInfo.status.className}`}>{paymentInfo.status.text}</span>
                                            </span>
                                        </div>
                                    </li>
                                );
                            })}
                        </ul>
                    ) : (
                        <p>No sales recorded yet.</p>
                    )}
                </div>
                 <div className="card activity-card">
                    <h3 className="card-header-title">Top Selling Products (All Time)</h3>
                    {topSellingProducts.length > 0 ? (
                        <ul className="activity-list">
                            {topSellingProducts.map(({ product, quantitySold }) => {
                                if (!product) return null;
                                return (
                                    <li key={product.id}>
                                        <div className="activity-item">
                                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                                <img src={product.image} alt={product.name} className="product-image-thumb" style={{ width: '40px', height: '40px' }} />
                                                <span><strong>{product.name}</strong></span>
                                            </div>
                                            <strong style={{ color: 'var(--primary-color)' }}>{quantitySold} sold</strong>
                                        </div>
                                    </li>
                                );
                            })}
                        </ul>
                    ) : (
                        <p>No sales data to show.</p>
                    )}
                </div>
            </div>
            <DeveloperCredit />
        </div>
    );
};

// New Sale Page
const NewSale: React.FC = () => {
    const { state, setState, setActivePage, formatCurrency } = useAppContext();
    const [cart, setCart] = useState<SaleItem[]>([]);
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
    const [quantity, setQuantity] = useState<string>("1");
    const [selectedCustomer, setSelectedCustomer] = useState<Customer>(WALK_IN_CUSTOMER);
    const [discount, setDiscount] = useState<string>("0");
    const [amountPaid, setAmountPaid] = useState<string>("");
    const [showCustomerModal, setShowCustomerModal] = useState(false);
    const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString().split('T')[0]);

    const availableProducts = useMemo(() => state.products.filter(p => p.stock > 0), [state.products]);

    const handleAddToCart = () => {
        if (!selectedProduct || !quantity) return;
        const qty = parseInt(quantity, 10);
        if (isNaN(qty) || qty <= 0) {
            alert("Please enter a valid quantity.");
            return;
        }

        if (qty > selectedProduct.stock) {
            alert(`Not enough stock for ${selectedProduct.name}. Available: ${selectedProduct.stock}`);
            return;
        }

        const existingCartItemIndex = cart.findIndex(item => item.productId === selectedProduct.id);
        
        if (existingCartItemIndex > -1) {
            const updatedCart = [...cart];
            const newQty = updatedCart[existingCartItemIndex].quantity + qty;
            
            if (newQty > selectedProduct.stock) {
                 alert(`Not enough stock for ${selectedProduct.name}. Available: ${selectedProduct.stock}, In cart: ${updatedCart[existingCartItemIndex].quantity}`);
                 return;
            }

            updatedCart[existingCartItemIndex].quantity = newQty;
            setCart(updatedCart);
        } else {
            setCart([...cart, {
                productId: selectedProduct.id,
                quantity: qty,
                saleRate: selectedProduct.saleRate,
                purchaseRate: selectedProduct.purchaseRate,
            }]);
        }
        setSelectedProduct(null);
        setQuantity("1");
    };

    const handleUpdateCartItem = (productId: string, newQuantityStr: string) => {
        if (newQuantityStr === '') {
            setCart(cart.map(item => item.productId === productId ? { ...item, quantity: 0 } : item));
            return;
        }

        const newQuantity = parseInt(newQuantityStr, 10);
        if (isNaN(newQuantity) || newQuantity < 0) {
             return;
        }
        
        const product = state.products.find(p => p.id === productId);
        
        if (product && newQuantity > product.stock) {
            alert(`Not enough stock for ${product.name}. Max available: ${product.stock}.`);
             setCart(cart.map(item => item.productId === productId ? { ...item, quantity: product.stock } : item));
            return;
        }

        if (newQuantity === 0) {
            handleRemoveFromCart(productId);
        } else {
            setCart(cart.map(item => item.productId === productId ? { ...item, quantity: newQuantity } : item));
        }
    };

    const handleRemoveFromCart = (productId: string) => {
        setCart(cart.filter(item => item.productId !== productId));
    };

    const totals = useMemo(() => {
        const subTotal = cart.reduce((sum, item) => sum + (item.quantity * item.saleRate), 0);
        const finalDiscount = parseFloat(discount) || 0;
        const finalAmount = subTotal - finalDiscount;
        const paid = parseFloat(amountPaid) || 0;
        const balance = finalAmount - paid;
        return { subTotal, finalDiscount, finalAmount, paid, balance };
    }, [cart, discount, amountPaid]);

    const finalizeSale = () => {
        if (cart.length === 0) {
            alert("Cart is empty.");
            return;
        }
        
        if (totals.finalAmount < 0) {
            alert("Final amount cannot be negative.");
            return;
        }

        const newInvoiceId = `INV-${Date.now()}`;
        const newInvoice: Invoice = {
            id: newInvoiceId,
            date: new Date(invoiceDate).toISOString(),
            customerId: selectedCustomer.id === 'walk-in' ? undefined : selectedCustomer.id,
            items: cart.filter(item => item.quantity > 0), 
            subTotal: totals.subTotal,
            discount: totals.finalDiscount,
            finalAmount: totals.finalAmount,
            payments: []
        };
        
        if (totals.paid > 0) {
            newInvoice.payments.push({
                date: new Date(invoiceDate).toISOString(),
                amount: Math.min(totals.paid, totals.finalAmount)
            });
        }
        
        const updatedProducts = state.products.map(p => {
            const cartItem = cart.find(item => item.productId === p.id);
            if (cartItem) {
                return { ...p, stock: p.stock - cartItem.quantity };
            }
            return p;
        });
        
        setState(prevState => ({
            ...prevState,
            invoices: [newInvoice, ...prevState.invoices],
            products: updatedProducts
        }));
        
        setActivePage('invoices');
    };

    return (
        <div className="new-sale-layout">
            <div className="card sale-details">
                <div className="card-header-title">Create New Sale</div>

                <div className="add-item-form">
                    <div className="form-group">
                        <label>Select Product</label>
                         <SearchableSelect
                            options={availableProducts}
                            value={selectedProduct}
                            onChange={(product) => setSelectedProduct(product)}
                            placeholder="Search products..."
                        />
                    </div>
                    <div className="form-group" style={{ flexGrow: 0, width: '100px' }}>
                         <label>Quantity</label>
                        <input
                            type="number"
                            value={quantity}
                            onChange={e => setQuantity(e.target.value)}
                            min="1"
                            disabled={!selectedProduct}
                        />
                    </div>
                    <button className="btn btn-primary" onClick={handleAddToCart} disabled={!selectedProduct || !quantity || parseInt(quantity, 10) <= 0}>
                        Add to Cart
                    </button>
                </div>
                
                <div className="cart-items-list" style={{ marginTop: '20px' }}>
                    <div className="cart-header cart-item-edit">
                        <span>Product</span>
                        <span>Price</span>
                        <span style={{textAlign: 'center'}}>Qty</span>
                        <span style={{textAlign: 'right'}}>Total</span>
                        <span>Action</span>
                    </div>
                     {cart.length > 0 ? (
                        cart.map(item => {
                            const product = state.products.find(p => p.id === item.productId);
                            if (!product) return null;
                            return (
                                <div key={item.productId} className="cart-item-edit">
                                    <span title={product.name}>{product.name}</span>
                                    <span>{formatCurrency(item.saleRate)}</span>
                                    <span>
                                         <input 
                                            type="number" 
                                            value={item.quantity === 0 ? '' : item.quantity} 
                                            onChange={(e) => handleUpdateCartItem(item.productId, e.target.value)} 
                                            className="cart-quantity-input" 
                                            min="0"
                                            placeholder="0"
                                        />
                                    </span>
                                    <span style={{textAlign: 'right'}}>{formatCurrency(item.quantity * item.saleRate)}</span>
                                    <button className="btn btn-icon btn-danger" onClick={() => handleRemoveFromCart(item.productId)}>&times;</button>
                                </div>
                            );
                        })
                    ) : (
                        <p style={{ textAlign: 'center', padding: '20px', color: 'var(--light-text-color)' }}>Cart is empty</p>
                    )}
                </div>
            </div>

            <div className="card sale-summary">
                <div className="card-header-title">Sale Summary</div>
                <SearchableSelect
                    options={[WALK_IN_CUSTOMER, ...state.customers]}
                    value={selectedCustomer}
                    onChange={(val) => setSelectedCustomer(val || WALK_IN_CUSTOMER)}
                    placeholder="Select Customer"
                    onAddNew={() => setShowCustomerModal(true)}
                />

                <div className="summary-row" style={{marginTop: '15px'}}>
                    <span>Subtotal</span>
                    <span>{formatCurrency(totals.subTotal)}</span>
                </div>
                <div className="summary-row">
                    <span>Discount</span>
                    <input 
                        type="number"
                        placeholder="0.00"
                        value={discount}
                        onChange={e => setDiscount(e.target.value)}
                        style={{ width: '100px', textAlign: 'right', padding: '5px' }}
                    />
                </div>
                 <div className="summary-row total">
                    <span>Total</span>
                    <span>{formatCurrency(totals.finalAmount)}</span>
                </div>
                
                <div className="payment-section">
                    <div className="form-group">
                        <label htmlFor="invoice-date">Invoice Date</label>
                        <input
                            type="date"
                            id="invoice-date"
                            value={invoiceDate}
                            onChange={(e) => setInvoiceDate(e.target.value)}
                        />
                    </div>
                    <div className="form-group">
                        <label>Amount Paid</label>
                         <input
                            type="number"
                            placeholder="0.00"
                            value={amountPaid}
                            onChange={e => setAmountPaid(e.target.value)}
                        />
                    </div>
                     {totals.balance < 0 && (
                        <div className="summary-row change">
                            <span>Change Due</span>
                            <span>{formatCurrency(Math.abs(totals.balance))}</span>
                        </div>
                    )}
                     {totals.balance > 0 && (
                        <div className="summary-row due">
                            <span>Balance Due</span>
                            <span>{formatCurrency(totals.balance)}</span>
                        </div>
                    )}
                </div>

                <button
                    className="btn btn-primary"
                    style={{ width: '100%', marginTop: 'auto', paddingTop: '15px', paddingBottom: '15px', fontSize: '1.2rem' }}
                    onClick={finalizeSale}
                    disabled={cart.length === 0 || cart.every(i => i.quantity === 0) || totals.finalAmount < 0}
                >
                    Finalize Sale
                </button>
            </div>
             {showCustomerModal && (
                <ManageCustomersModal onClose={() => setShowCustomerModal(false)} onCustomerSelect={(customer) => {
                    setSelectedCustomer(customer);
                    setShowCustomerModal(false);
                }} />
            )}
        </div>
    );
};

// --- Invoices Page and Modals ---

const AddPaymentModal: React.FC<{
    invoice: Invoice;
    onClose: () => void;
}> = ({ invoice, onClose }) => {
    const { setState, formatCurrency } = useAppContext();
    const paymentInfo = getInvoicePaymentInfo(invoice);
    const [amount, setAmount] = useState<string>(paymentInfo.balanceDue.toFixed(2));
    const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split('T')[0]);

    const handleAddPayment = () => {
        const paymentAmount = parseFloat(amount);
        if (isNaN(paymentAmount) || paymentAmount <= 0) {
            alert('Please enter a valid payment amount.');
            return;
        }
        if (paymentAmount > paymentInfo.balanceDue + 0.01) { 
             alert(`Payment cannot exceed balance due (${formatCurrency(paymentInfo.balanceDue)}).`);
            return;
        }
        if (!paymentDate) {
            alert('Please select a payment date.');
            return;
        }

        setState(prev => {
            const updatedInvoices = prev.invoices.map(inv => {
                if (inv.id === invoice.id) {
                    const newPayments = [...(inv.payments || []), {
                        date: new Date(paymentDate).toISOString(),
                        amount: paymentAmount
                    }];
                    return { ...inv, payments: newPayments };
                }
                return inv;
            });
            return { ...prev, invoices: updatedInvoices };
        });

        onClose();
    };

    return (
        <Modal title={`Add Payment for Invoice #${invoice.id}`} onClose={onClose}>
            <div className="form-group">
                <label>Balance Due</label>
                <input type="text" readOnly value={formatCurrency(paymentInfo.balanceDue)} disabled />
            </div>
             <div className="form-group">
                <label htmlFor="payment-date">Payment Date</label>
                <input type="date" id="payment-date" value={paymentDate} onChange={e => setPaymentDate(e.target.value)} />
            </div>
            <div className="form-group">
                <label htmlFor="payment-amount">Payment Amount</label>
                <input
                    type="number"
                    id="payment-amount"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    placeholder="Enter amount"
                    max={paymentInfo.balanceDue.toFixed(2)}
                    autoFocus
                />
            </div>
            <div className="modal-footer">
                <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
                <button className="btn btn-primary" onClick={handleAddPayment}>Save Payment</button>
            </div>
        </Modal>
    );
};

const InvoiceDetailModal: React.FC<{
    invoice: Invoice;
    onClose: () => void;
    onDelete: (invoiceId: string) => void;
}> = ({ invoice, onClose, onDelete }) => {
    const { state, formatCurrency } = useAppContext();
    const { businessInfo, products, customers } = state;

    const customer = customers.find(c => c.id === invoice.customerId) || WALK_IN_CUSTOMER;
    const { amountReceived, balanceDue, status } = getInvoicePaymentInfo(invoice);

    const handlePrint = () => {
        printReceipt(invoice, businessInfo, products, customers);
    };

    const handleDelete = () => {
        onDelete(invoice.id);
        onClose();
    };

    return (
        <Modal title={`Invoice Detail - #${invoice.id}`} onClose={onClose}>
            <div className="invoice-detail-view">
                <header className="receipt-header">
                    {businessInfo.logo && <img src={businessInfo.logo} alt="Logo" className="receipt-logo"/>}
                    <p className="business-name">{businessInfo.name || 'Canteen POS'}</p>
                </header>
                
                <section className="invoice-info">
                    <p><strong>Invoice #:</strong> {invoice.id}</p>
                    <p><strong>Date:</strong> {new Date(invoice.date).toLocaleString()}</p>
                </section>
                <section className="customer-info">
                    <p><strong>Customer:</strong> {customer.name}</p>
                    {customer.mobile && <p><strong>Mobile:</strong> {customer.mobile}</p>}
                </section>

                <table className="items-table">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th className="col-total">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        {invoice.items.map(item => {
                            const product = products.find(p => p.id === item.productId);
                            return <tr key={item.productId}>
                                <td>
                                    <div className="item-name">{product?.name || 'N/A'}</div>
                                    <div className="item-qty-rate">{item.quantity} {product?.unit || ''} &times; {formatCurrency(item.saleRate)}</div>
                                </td>
                                <td className="col-total">{formatCurrency(item.quantity * item.saleRate)}</td>
                            </tr>;
                        })}
                    </tbody>
                </table>

                <section className="totals-section">
                    <div className="summary-row">
                        <span>Subtotal</span>
                        <span>{formatCurrency(invoice.subTotal)}</span>
                    </div>
                    <div className="summary-row">
                        <span>Discount</span>
                        <span>-{formatCurrency(invoice.discount)}</span>
                    </div>
                    <div className="summary-row grand-total">
                        <span>TOTAL</span>
                        <span>{formatCurrency(invoice.finalAmount)}</span>
                    </div>
                </section>

                <section className="payment-details">
                    <div className="summary-row">
                        <span>Amount Paid</span>
                        <span>{formatCurrency(amountReceived)}</span>
                    </div>
                    <div className="summary-row">
                        <span>Balance Due</span>
                        <span>{formatCurrency(balanceDue)}</span>
                    </div>
                    <div className="summary-row">
                        <span>Status</span>
                        <span className={`status-badge ${status.className}`}>{status.text}</span>
                    </div>
                </section>
            </div>
            <div className="modal-footer" style={{ justifyContent: 'space-between' }}>
                <button className="btn btn-danger" onClick={handleDelete}>Delete Invoice</button>
                <div>
                    <button className="btn btn-secondary" onClick={onClose}>Close</button>
                    <button className="btn btn-primary" onClick={handlePrint}>Print Receipt</button>
                </div>
            </div>
        </Modal>
    );
};

const Invoices: React.FC = () => {
    const { state, setState, formatCurrency } = useAppContext();
    const { invoices, customers } = state;
    const [searchTerm, setSearchTerm] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [invoiceToView, setInvoiceToView] = useState<Invoice | null>(null);
    const [invoiceForPayment, setInvoiceForPayment] = useState<Invoice | null>(null);

    const handleDeleteInvoice = (invoiceId: string) => {
        const invoiceToDelete = invoices.find(inv => inv.id === invoiceId);
        if (!invoiceToDelete) return;

        if (window.confirm(`Are you sure you want to delete Invoice #${invoiceId}? This will restore the stock for all items sold in this invoice. This action cannot be undone.`)) {
            setState(prev => {
                // Create a map of product ID -> quantity to restore
                const stockToRestore = new Map<string, number>();
                invoiceToDelete.items.forEach(item => {
                    stockToRestore.set(item.productId, (stockToRestore.get(item.productId) || 0) + item.quantity);
                });

                // Update product stock
                const updatedProducts = prev.products.map(product => {
                    if (stockToRestore.has(product.id)) {
                        return { ...product, stock: product.stock + stockToRestore.get(product.id)! };
                    }
                    return product;
                });

                // Remove the invoice
                const updatedInvoices = prev.invoices.filter(inv => inv.id !== invoiceId);

                return { ...prev, invoices: updatedInvoices, products: updatedProducts };
            });
        }
    };

    const filteredInvoices = useMemo(() => {
        return invoices
            .filter(inv => {
                const customer = customers.find(c => c.id === inv.customerId);
                const customerName = customer ? customer.name : 'walk-in customer';
                const lowerSearch = searchTerm.toLowerCase();

                const matchesSearch =
                    inv.id.toLowerCase().includes(lowerSearch) ||
                    customerName.toLowerCase().includes(lowerSearch);
                
                if (!matchesSearch) return false;

                if (startDate && new Date(inv.date) < new Date(startDate)) return false;
                
                if (endDate) {
                    const end = new Date(endDate);
                    end.setHours(23, 59, 59, 999); 
                    if (new Date(inv.date) > end) return false;
                }

                return true;
            })
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [invoices, customers, searchTerm, startDate, endDate]);

    return (
        <div className="card">
            <h3 className="card-header-title">Manage Invoices</h3>
            <div className="toolbar">
                <div className="search-bar">
                    <input
                        type="text"
                        placeholder="Search by Invoice ID or Customer Name..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                </div>
                <div className="filter-control">
                    <label>From:</label>
                    <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
                </div>
                <div className="filter-control">
                     <label>To:</label>
                    <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
                </div>
                 <button className="btn btn-secondary" onClick={() => { setSearchTerm(''); setStartDate(''); setEndDate(''); }}>Clear Filters</button>
            </div>
            <div className="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Invoice ID</th>
                            <th>Customer</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Paid</th>
                            <th>Due</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredInvoices.length > 0 ? filteredInvoices.map(invoice => {
                            const customer = customers.find(c => c.id === invoice.customerId);
                            const paymentInfo = getInvoicePaymentInfo(invoice);
                            return (
                                <tr key={invoice.id}>
                                    <td>{invoice.id}</td>
                                    <td>{customer?.name || 'Walk-in'}</td>
                                    <td>{new Date(invoice.date).toLocaleDateString()}</td>
                                    <td>{formatCurrency(invoice.finalAmount)}</td>
                                    <td>{formatCurrency(paymentInfo.amountReceived)}</td>
                                    <td>{formatCurrency(paymentInfo.balanceDue)}</td>
                                    <td><span className={`status-badge ${paymentInfo.status.className}`}>{paymentInfo.status.text}</span></td>
                                    <td className="actions">
                                        <button className="btn btn-primary" onClick={() => setInvoiceToView(invoice)}>View</button>
                                        {paymentInfo.balanceDue > 0.01 && (
                                            <button className="btn btn-secondary" onClick={() => setInvoiceForPayment(invoice)}>Pay</button>
                                        )}
                                    </td>
                                </tr>
                            )
                        }) : (
                            <tr>
                                <td colSpan={8} style={{ textAlign: 'center' }}>No invoices found.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {invoiceToView && <InvoiceDetailModal invoice={invoiceToView} onDelete={handleDeleteInvoice} onClose={() => setInvoiceToView(null)} />}
            {invoiceForPayment && <AddPaymentModal invoice={invoiceForPayment} onClose={() => setInvoiceForPayment(null)} />}
        </div>
    );
};


// --- Product Management Components ---
const ProductFormModal: React.FC<{
    productToEdit: Product | null;
    onClose: () => void;
}> = ({ productToEdit, onClose }) => {
    const { setState } = useAppContext();
    const [name, setName] = useState('');
    const [category, setCategory] = useState('');
    const [unit, setUnit] = useState('');
    const [purchaseRate, setPurchaseRate] = useState('');
    const [saleRate, setSaleRate] = useState('');
    const [stock, setStock] = useState('');
    const [image, setImage] = useState('');
    const isEditing = !!productToEdit;

    useEffect(() => {
        if (productToEdit) {
            setName(productToEdit.name);
            setCategory(productToEdit.category);
            setUnit(productToEdit.unit);
            setPurchaseRate(String(productToEdit.purchaseRate));
            setSaleRate(String(productToEdit.saleRate));
            setStock(String(productToEdit.stock));
            setImage(productToEdit.image);
        }
    }, [productToEdit]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !saleRate || !unit) {
            alert('Product Name, Sale Rate, and Unit are required.');
            return;
        }

        const productData: Product = {
            id: isEditing ? productToEdit.id : `PROD-${Date.now()}`,
            name,
            category,
            unit,
            purchaseRate: parseFloat(purchaseRate) || 0,
            saleRate: parseFloat(saleRate) || 0,
            stock: parseInt(stock, 10) || 0,
            image,
        };

        setState(prev => {
            const products = isEditing
                ? prev.products.map(p => p.id === productData.id ? productData : p)
                : [...prev.products, productData];
            return { ...prev, products };
        });
        onClose();
    };

    return (
        <Modal title={isEditing ? 'Edit Product' : 'Add New Product'} onClose={onClose}>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="product-name">Product Name*</label>
                    <input
                        id="product-name"
                        type="text"
                        list="food-suggestions"
                        value={name}
                        onChange={e => setName(e.target.value)}
                        placeholder="e.g., Chicken Biryani"
                        required
                        autoFocus
                    />
                    <datalist id="food-suggestions">
                        {PAKISTANI_FOOD_SUGGESTIONS.map(food => (
                            <option key={food.id} value={food.name} />
                        ))}
                    </datalist>
                </div>
                <div className="form-group">
                    <label htmlFor="product-category">Category</label>
                    <input
                        id="product-category"
                        type="text"
                        value={category}
                        onChange={e => setCategory(e.target.value)}
                        placeholder="e.g., Rice, Drinks, Snacks"
                    />
                </div>
                 <div className="form-group">
                    <label htmlFor="product-unit">Unit*</label>
                    <input
                        id="product-unit"
                        type="text"
                        list="unit-suggestions"
                        value={unit}
                        onChange={e => setUnit(e.target.value)}
                        placeholder="e.g., Piece, Kg, Plate"
                        required
                    />
                    <datalist id="unit-suggestions">
                        {PAKISTANI_UNITS.map(u => (
                            <option key={u} value={u} />
                        ))}
                    </datalist>
                </div>
                 <div className="form-group">
                    <label htmlFor="purchase-rate">Purchase Rate</label>
                    <input
                        id="purchase-rate"
                        type="number"
                        step="0.01"
                        value={purchaseRate}
                        onChange={e => setPurchaseRate(e.target.value)}
                        placeholder="0.00"
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="sale-rate">Sale Rate*</label>
                    <input
                        id="sale-rate"
                        type="number"
                        step="0.01"
                        value={saleRate}
                        onChange={e => setSaleRate(e.target.value)}
                        placeholder="0.00"
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="stock">Initial Stock</label>
                    <input
                        id="stock"
                        type="number"
                        step="1"
                        value={stock}
                        onChange={e => setStock(e.target.value)}
                        placeholder="0"
                        disabled={isEditing}
                    />
                    {isEditing && <small>Stock must be updated through Purchases.</small>}
                </div>
                <ImageUpload label="Product Image" currentImage={image} onImageChange={setImage} />
                <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
                    <button type="submit" className="btn btn-primary">{isEditing ? 'Save Changes' : 'Add Product'}</button>
                </div>
            </form>
        </Modal>
    );
};

const ManageProducts: React.FC = () => {
    const { state, setState, formatCurrency } = useAppContext();
    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [productToEdit, setProductToEdit] = useState<Product | null>(null);

    const filteredProducts = useMemo(() => {
        return state.products
            .filter(p =>
                p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                p.category.toLowerCase().includes(searchTerm.toLowerCase())
            )
            .sort((a, b) => a.name.localeCompare(b.name));
    }, [state.products, searchTerm]);

    const handleOpenModalForAdd = () => {
        setProductToEdit(null);
        setIsModalOpen(true);
    };

    const handleOpenModalForEdit = (product: Product) => {
        setProductToEdit(product);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setProductToEdit(null);
    };

    const handleDeleteProduct = (productId: string) => {
        const isProductSold = state.invoices.some(invoice => invoice.items.some(item => item.productId === productId));
        if (isProductSold) {
            alert("Cannot delete this product because it has been sold in past invoices. Consider setting its stock to 0 to hide it from new sales, or removing it from all invoices first.");
            return;
        }

        const isProductInExpense = state.expenses.some(expense =>
            expense.expenseType === 'CanteenUsage' && expense.items?.some(item => item.productId === productId)
        );
        if (isProductInExpense) {
            alert("Cannot delete this product because it is part of a recorded expense. You may need to remove it from the expense first.");
            return;
        }

        const isProductInPurchase = state.purchases.some(purchase =>
            purchase.items.some(item => item.productId === productId)
        );
        if (isProductInPurchase) {
            alert("Cannot delete this product because it's part of a purchase history. Deleting it would corrupt your inventory and profit/loss records.");
            return;
        }

        if (window.confirm("Are you sure you want to delete this product? This action cannot be undone.")) {
            setState(prev => ({
                ...prev,
                products: prev.products.filter(p => p.id !== productId),
            }));
        }
    };
    
    return (
        <div className="card">
            <h3 className="card-header-title">Manage Products</h3>
             <div className="toolbar">
                <div className="search-bar">
                    <input
                        type="text"
                        placeholder="Search by product name or category..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                </div>
                <button className="btn btn-primary" onClick={handleOpenModalForAdd}>
                    Add New Product
                </button>
            </div>
            <div className="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Purchase Rate</th>
                            <th>Sale Rate</th>
                            <th>Stock</th>
                            <th>Unit</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                         {filteredProducts.length > 0 ? filteredProducts.map(product => (
                            <tr key={product.id}>
                                <td>
                                    <img src={product.image || 'https://via.placeholder.com/50'} alt={product.name} className="product-image-thumb" />
                                </td>
                                <td>{product.name}</td>
                                <td>{product.category || 'N/A'}</td>
                                <td>{formatCurrency(product.purchaseRate)}</td>
                                <td>{formatCurrency(product.saleRate)}</td>
                                <td className={product.stock <= 5 ? 'low-stock' : ''}>{product.stock}</td>
                                <td>{product.unit}</td>
                                <td className="actions">
                                    <button className="btn btn-secondary" onClick={() => handleOpenModalForEdit(product)}>Edit</button>
                                    <button className="btn btn-danger" onClick={() => handleDeleteProduct(product.id)}>Delete</button>
                                </td>
                            </tr>
                        )) : (
                             <tr>
                                <td colSpan={8} style={{ textAlign: 'center' }}>No products found.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {isModalOpen && <ProductFormModal productToEdit={productToEdit} onClose={handleCloseModal} />}
        </div>
    );
};

// --- Customer Management Components ---

const CustomerFormModal: React.FC<{
    customerToEdit: Customer | null;
    onClose: () => void;
}> = ({ customerToEdit, onClose }) => {
    const { state, setState } = useAppContext();
    const [name, setName] = useState('');
    const [mobile, setMobile] = useState('');
    const [address, setAddress] = useState('');
    const isEditing = !!customerToEdit;

    useEffect(() => {
        if (customerToEdit) {
            setName(customerToEdit.name);
            setMobile(customerToEdit.mobile);
            setAddress(customerToEdit.address);
        }
    }, [customerToEdit]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name.trim()) {
            alert('Customer name is required.');
            return;
        }

        const trimmedName = name.trim().toLowerCase();
        const trimmedMobile = mobile.trim();

        const isDuplicate = state.customers.some(c => {
            if (isEditing && c.id === customerToEdit.id) {
                return false;
            }
            const cName = c.name.trim().toLowerCase();
            const cMobile = c.mobile.trim();
            if (cName === trimmedName) {
                if (!trimmedMobile && !cMobile) return true;
                if (trimmedMobile && cMobile && trimmedMobile === cMobile) return true;
            }
            return false;
        });

        if (isDuplicate) {
            alert('A customer with the same name and/or mobile number already exists.');
            return;
        }

        const customerData: Customer = {
            id: isEditing ? customerToEdit.id : `CUST-${Date.now()}`,
            name: name.trim(),
            mobile: mobile.trim(),
            address: address.trim(),
        };

        setState(prev => {
            const customers = isEditing
                ? prev.customers.map(c => c.id === customerData.id ? customerData : c)
                : [...prev.customers, customerData];
            return { ...prev, customers: customers.sort((a,b) => a.name.localeCompare(b.name)) };
        });
        onClose();
    };

    return (
        <Modal title={isEditing ? 'Edit Customer' : 'Add New Customer'} onClose={onClose}>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Customer Name*</label>
                    <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Full Name" required autoFocus />
                </div>
                <div className="form-group">
                    <label>Mobile Number</label>
                    <input type="text" value={mobile} onChange={e => setMobile(e.target.value)} placeholder="0300-1234567" />
                </div>
                <div className="form-group">
                    <label>Address</label>
                    <input type="text" value={address} onChange={e => setAddress(e.target.value)} placeholder="Optional address" />
                </div>
                <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
                    <button type="submit" className="btn btn-primary">{isEditing ? 'Save Changes' : 'Add Customer'}</button>
                </div>
            </form>
        </Modal>
    );
};

const CustomerDetailModal: React.FC<{
    customer: Customer;
    onClose: () => void;
}> = ({ customer, onClose }) => {
    const { state, formatCurrency } = useAppContext();
    const { invoices } = state;

    const [invoiceToView, setInvoiceToView] = useState<Invoice | null>(null);

    const customerData = useMemo(() => {
        const customerInvoices = invoices
            .filter(inv => inv.customerId === customer.id)
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        
        const balance = customerInvoices.reduce((sum, inv) => {
            const { balanceDue } = getInvoicePaymentInfo(inv);
            return sum + balanceDue;
        }, 0);

        return { invoices: customerInvoices, balance };
    }, [invoices, customer.id]);

    return (
        <>
            <Modal title={`Customer Details: ${customer.name}`} onClose={onClose}>
                <div className="report-summary-grid" style={{ marginBottom: '15px' }}>
                    <div className="summary-box">
                        <span className="summary-box-label">Mobile Number</span>
                        <span className="summary-box-value" style={{fontSize: '18px'}}>{customer.mobile || 'N/A'}</span>
                    </div>
                     <div className="summary-box">
                        <span className="summary-box-label">Total Balance Due</span>
                        <span className={`summary-box-value ${customerData.balance > 0 ? 'loss' : 'profit'}`}>{formatCurrency(customerData.balance)}</span>
                    </div>
                </div>
                
                <div className="card-header-title" style={{borderTop: '1px solid var(--border-color)', paddingTop: '15px'}}>Invoice History ({customerData.invoices.length})</div>
                 <div className="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Invoice ID</th>
                                <th>Date</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        {customerData.invoices.length > 0 ? customerData.invoices.map(invoice => {
                            const paymentInfo = getInvoicePaymentInfo(invoice);
                            return (
                                <tr key={invoice.id}>
                                    <td>{invoice.id}</td>
                                    <td>{new Date(invoice.date).toLocaleDateString()}</td>
                                    <td>{formatCurrency(invoice.finalAmount)}</td>
                                    <td><span className={`status-badge ${paymentInfo.status.className}`}>{paymentInfo.status.text}</span></td>
                                    <td className="actions">
                                        <button className="btn btn-secondary" onClick={() => setInvoiceToView(invoice)}>View</button>
                                    </td>
                                </tr>
                            )
                        }) : (
                            <tr>
                                <td colSpan={5} style={{ textAlign: 'center' }}>No invoices found for this customer.</td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>

                <div className="modal-footer">
                    <button type="button" className="btn btn-primary" onClick={onClose}>Close</button>
                </div>
            </Modal>
            {invoiceToView && <InvoiceDetailModal invoice={invoiceToView} onDelete={()=>{}} onClose={() => setInvoiceToView(null)} />}
        </>
    );
};

const ManageCustomers: React.FC = () => {
    const { state, setState, formatCurrency } = useAppContext();
    const { customers, invoices } = state;
    const [searchTerm, setSearchTerm] = useState('');
    const [isFormModalOpen, setFormModalOpen] = useState(false);
    const [customerToEdit, setCustomerToEdit] = useState<Customer | null>(null);
    const [customerToView, setCustomerToView] = useState<Customer | null>(null);

    const filteredCustomers = useMemo(() => {
        return customers
            .map(customer => ({
                ...customer,
                balance: getCustomerBalance(customer.id, invoices)
            }))
            .filter(c =>
                c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                c.mobile.toLowerCase().includes(searchTerm.toLowerCase())
            )
            .sort((a, b) => a.name.localeCompare(b.name));
    }, [customers, invoices, searchTerm]);

    const handleOpenModalForAdd = () => {
        setCustomerToEdit(null);
        setFormModalOpen(true);
    };

    const handleOpenModalForEdit = (customer: Customer) => {
        setCustomerToEdit(customer);
        setFormModalOpen(true);
    };

    const handleCloseModal = () => {
        setFormModalOpen(false);
        setCustomerToEdit(null);
    };

    const handleDeleteCustomer = (customerId: string) => {
        const hasInvoices = invoices.some(inv => inv.customerId === customerId);
        if (hasInvoices) {
            alert("Cannot delete this customer as they have existing invoices. Consider clearing their invoice history first.");
            return;
        }

        if (window.confirm("Are you sure you want to delete this customer? This action cannot be undone.")) {
            setState(prev => ({
                ...prev,
                customers: prev.customers.filter(c => c.id !== customerId),
            }));
        }
    };
    
    const handleViewDetails = (customer: Customer) => {
        setCustomerToView(customer);
    };

    return (
        <div className="card">
            <h3 className="card-header-title">Manage Customers</h3>
            <div className="toolbar">
                <div className="search-bar">
                    <input
                        type="text"
                        placeholder="Search by customer name or mobile..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                </div>
                <button className="btn btn-primary" onClick={handleOpenModalForAdd}>
                    Add New Customer
                </button>
            </div>
            <div className="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Mobile</th>
                            <th>Address</th>
                            <th>Balance Due</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredCustomers.length > 0 ? filteredCustomers.map(customer => (
                            <tr key={customer.id}>
                                <td>
                                     <a href="#" className="customer-name-clickable" onClick={(e) => { e.preventDefault(); handleViewDetails(customer); }}>
                                        {customer.name}
                                    </a>
                                </td>
                                <td>{customer.mobile || 'N/A'}</td>
                                <td>{customer.address || 'N/A'}</td>
                                <td className={customer.balance > 0 ? 'loss' : ''}>
                                    {formatCurrency(customer.balance)}
                                </td>
                                <td className="actions">
                                    <button className="btn btn-secondary" onClick={() => handleOpenModalForEdit(customer)}>Edit</button>
                                    <button className="btn btn-danger" onClick={() => handleDeleteCustomer(customer.id)}>Delete</button>
                                </td>
                            </tr>
                        )) : (
                             <tr>
                                <td colSpan={5} style={{ textAlign: 'center' }}>No customers found.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
            {isFormModalOpen && <CustomerFormModal customerToEdit={customerToEdit} onClose={handleCloseModal} />}
            {customerToView && <CustomerDetailModal customer={customerToView} onClose={() => setCustomerToView(null)} />}
        </div>
    );
};

const ManageCustomersModal: React.FC<{onClose: ()=>void, onCustomerSelect: (c: Customer)=>void}> = ({onClose, onCustomerSelect}) => {
     const { state, setState } = useAppContext();
     const [name, setName] = useState('');
     const [mobile, setMobile] = useState('');
     const [address, setAddress] = useState('');

     const handleAddCustomer = () => {
        if (!name.trim()) {
            alert("Customer name is required.");
            return;
        }

        const trimmedName = name.trim().toLowerCase();
        const trimmedMobile = mobile.trim();
        const isDuplicate = state.customers.some(c => {
             const cName = c.name.trim().toLowerCase();
             const cMobile = c.mobile.trim();
             if (cName === trimmedName) {
                 if (!trimmedMobile && !cMobile) return true;
                 if (trimmedMobile && cMobile && trimmedMobile === cMobile) return true;
             }
             return false;
        });

        if (isDuplicate) {
             alert('A customer with the same name and/or mobile number already exists.');
             return;
        }
        
        const newCustomer: Customer = { id: `CUST-${Date.now()}`, name: name.trim(), mobile: mobile.trim(), address: address.trim() };
        setState(prev => ({...prev, customers: [...prev.customers, newCustomer].sort((a,b) => a.name.localeCompare(b.name))}));
        onCustomerSelect(newCustomer);
     }

    return (
        <Modal title="Add New Customer" onClose={onClose}>
            <div className="form-group">
                <label>Customer Name*</label>
                <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Full Name" required autoFocus/>
            </div>
            <div className="form-group">
                <label>Mobile Number</label>
                <input type="text" value={mobile} onChange={e => setMobile(e.target.value)} placeholder="Mobile Number"/>
            </div>
             <div className="form-group">
                <label>Address</label>
                <input type="text" value={address} onChange={e => setAddress(e.target.value)} placeholder="Address"/>
            </div>
            <div className="modal-footer">
                <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
                <button className="btn btn-primary" onClick={handleAddCustomer}>Save and Select</button>
            </div>
        </Modal>
    );
};

const EmployeeFormModal: React.FC<{
    employeeToEdit: Employee | null;
    onClose: () => void;
}> = ({ employeeToEdit, onClose }) => {
    const { setState } = useAppContext();
    const [name, setName] = useState('');
    const [mobile, setMobile] = useState('');
    const [address, setAddress] = useState('');
    const [designation, setDesignation] = useState('');
    const [joiningDate, setJoiningDate] = useState(new Date().toISOString().split('T')[0]);
    const [salary, setSalary] = useState('');
    const [photo, setPhoto] = useState('');
    const isEditing = !!employeeToEdit;

    useEffect(() => {
        if (employeeToEdit) {
            setName(employeeToEdit.name);
            setMobile(employeeToEdit.mobile);
            setAddress(employeeToEdit.address);
            setDesignation(employeeToEdit.designation);
            setJoiningDate(employeeToEdit.joiningDate.split('T')[0]);
            setSalary(String(employeeToEdit.salary));
            setPhoto(employeeToEdit.photo);
        }
    }, [employeeToEdit]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !designation || !salary || !joiningDate) {
            alert('Name, Designation, Joining Date, and Salary are required.');
            return;
        }

        const employeeData: Employee = {
            id: isEditing ? employeeToEdit.id : `EMP-${Date.now()}`,
            name,
            mobile,
            address,
            designation,
            joiningDate: new Date(joiningDate).toISOString(),
            salary: parseFloat(salary) || 0,
            photo,
        };

        setState(prev => {
            const employees = isEditing
                ? prev.employees.map(p => p.id === employeeData.id ? employeeData : p)
                : [...prev.employees, employeeData];
            return { ...prev, employees };
        });
        onClose();
    };

    return (
        <Modal title={isEditing ? 'Edit Employee' : 'Add New Employee'} onClose={onClose}>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Employee Name*</label>
                    <input type="text" value={name} onChange={e => setName(e.target.value)} required autoFocus />
                </div>
                <div className="form-group">
                    <label>Designation*</label>
                    <input type="text" value={designation} onChange={e => setDesignation(e.target.value)} required />
                </div>
                <div className="form-group">
                    <label>Mobile Number</label>
                    <input type="text" value={mobile} onChange={e => setMobile(e.target.value)} />
                </div>
                <div className="form-group">
                    <label>Address</label>
                    <input type="text" value={address} onChange={e => setAddress(e.target.value)} />
                </div>
                <div className="form-group">
                    <label>Joining Date*</label>
                    <input type="date" value={joiningDate} onChange={e => setJoiningDate(e.target.value)} required />
                </div>
                <div className="form-group">
                    <label>Salary*</label>
                    <input type="number" step="0.01" value={salary} onChange={e => setSalary(e.target.value)} placeholder="0.00" required />
                </div>
                <ImageUpload label="Employee Photo" currentImage={photo} onImageChange={setPhoto} />
                <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
                    <button type="submit" className="btn btn-primary">{isEditing ? 'Save Changes' : 'Add Employee'}</button>
                </div>
            </form>
        </Modal>
    );
};

const ManageEmployees: React.FC = () => {
    const { state, setState, formatCurrency } = useAppContext();
    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [employeeToEdit, setEmployeeToEdit] = useState<Employee | null>(null);

    const filteredEmployees = useMemo(() => {
        return state.employees
            .filter(e =>
                e.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                e.designation.toLowerCase().includes(searchTerm.toLowerCase())
            )
            .sort((a, b) => a.name.localeCompare(b.name));
    }, [state.employees, searchTerm]);

    const handleOpenModalForAdd = () => {
        setEmployeeToEdit(null);
        setIsModalOpen(true);
    };

    const handleOpenModalForEdit = (employee: Employee) => {
        setEmployeeToEdit(employee);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEmployeeToEdit(null);
    };

    const handleDeleteEmployee = (employeeId: string) => {
        const hasSalaryExpenses = state.expenses.some(expense =>
            expense.expenseType === 'Salary' && expense.employeeId === employeeId
        );

        if (hasSalaryExpenses) {
            alert("Cannot delete this employee because they have salary expenses recorded. Please remove the associated salary payments first.");
            return;
        }

        if (window.confirm("Are you sure you want to delete this employee? This action cannot be undone.")) {
            setState(prev => ({
                ...prev,
                employees: prev.employees.filter(e => e.id !== employeeId),
            }));
        }
    };

    return (
        <div className="card">
            <h3 className="card-header-title">Manage Employees</h3>
            <div className="toolbar">
                <div className="search-bar">
                    <input
                        type="text"
                        placeholder="Search by name or designation..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                </div>
                <button className="btn btn-primary" onClick={handleOpenModalForAdd}>Add New Employee</button>
            </div>
            <div className="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Name</th>
                            <th>Designation</th>
                            <th>Mobile</th>
                            <th>Salary</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredEmployees.length > 0 ? filteredEmployees.map(employee => (
                            <tr key={employee.id}>
                                <td><img src={employee.photo || 'https://via.placeholder.com/50'} alt={employee.name} className="product-image-thumb" style={{ borderRadius: '50%' }} /></td>
                                <td>{employee.name}</td>
                                <td>{employee.designation}</td>
                                <td>{employee.mobile}</td>
                                <td>{formatCurrency(employee.salary)}</td>
                                <td className="actions">
                                    <button className="btn btn-secondary" onClick={() => handleOpenModalForEdit(employee)}>Edit</button>
                                    <button className="btn btn-danger" onClick={() => handleDeleteEmployee(employee.id)}>Delete</button>
                                </td>
                            </tr>
                        )) : (
                            <tr><td colSpan={6} style={{ textAlign: 'center' }}>No employees found.</td></tr>
                        )}
                    </tbody>
                </table>
            </div>
            {isModalOpen && <EmployeeFormModal employeeToEdit={employeeToEdit} onClose={handleCloseModal} />}
        </div>
    );
};

const ExpenseFormModal: React.FC<{
    onClose: () => void;
}> = ({ onClose }) => {
    const { state, setState, formatCurrency } = useAppContext();
    const [expenseType, setExpenseType] = useState<'General' | 'Salary' | 'CanteenUsage'>('General');
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [title, setTitle] = useState('');
    const [amount, setAmount] = useState('');
    const [category, setCategory] = useState('');
    const [newCategory, setNewCategory] = useState('');

    // Salary specific state
    const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);

    // Canteen Usage specific state
    const [items, setItems] = useState<ExpenseItem[]>([]);
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
    const [quantity, setQuantity] = useState('');

    useEffect(() => {
        if (expenseType === 'Salary' && selectedEmployee) {
            setTitle(`Salary for ${selectedEmployee.name}`);
            setAmount(String(selectedEmployee.salary));
        } else if (expenseType !== 'CanteenUsage') {
            setTitle('');
            setAmount('');
        }
    }, [expenseType, selectedEmployee]);

    useEffect(() => {
        if (expenseType === 'CanteenUsage') {
            const total = items.reduce((sum, item) => sum + (item.quantity * item.purchaseRate), 0);
            setAmount(String(total));
            setTitle(`Canteen Usage - ${items.length} items`);
        }
    }, [items, expenseType]);
    
    const handleAddCanteenItem = () => {
        if (!selectedProduct || !quantity) return;
        const qty = parseFloat(quantity);
        if (isNaN(qty) || qty <= 0) { alert('Invalid quantity'); return; }
        if (qty > selectedProduct.stock) { alert(`Not enough stock. Available: ${selectedProduct.stock}`); return; }

        setItems(prevItems => [...prevItems, { productId: selectedProduct.id, quantity: qty, purchaseRate: selectedProduct.purchaseRate }]);
        setSelectedProduct(null);
        setQuantity('');
    };

    const handleRemoveCanteenItem = (productId: string) => {
        setItems(prevItems => prevItems.filter(item => item.productId !== productId));
    };

    const handleSubmit = () => {
        const finalAmount = parseFloat(amount);
        if (!date || !title || isNaN(finalAmount) || finalAmount < 0) {
            alert('Please fill all required fields with valid values.');
            return;
        }

        const finalCategory = category === 'add_new' ? newCategory : category;
        if (!finalCategory) {
            alert('Please select or add a category.');
            return;
        }

        const newExpense: Expense = {
            id: `EXP-${Date.now()}`,
            expenseType,
            date: new Date(date).toISOString(),
            title,
            amount: finalAmount,
            category: finalCategory,
        };

        if (expenseType === 'Salary') {
            if (!selectedEmployee) { alert('Please select an employee.'); return; }
            newExpense.employeeId = selectedEmployee.id;
        }

        if (expenseType === 'CanteenUsage') {
            if (items.length === 0) { alert('Please add at least one item for canteen usage.'); return; }
            newExpense.items = items;
        }

        setState(prev => {
            const updatedState = { ...prev };
            
            // Add new category if created
            if (category === 'add_new' && !prev.expenseCategories.includes(newCategory)) {
                updatedState.expenseCategories = [...prev.expenseCategories, newCategory];
            }
            
            // Deduct stock for canteen usage
            if (expenseType === 'CanteenUsage') {
                const stockUpdates = new Map<string, number>();
                items.forEach(item => {
                    stockUpdates.set(item.productId, (stockUpdates.get(item.productId) || 0) + item.quantity);
                });
                updatedState.products = prev.products.map(p => {
                    if (stockUpdates.has(p.id)) {
                        return { ...p, stock: p.stock - stockUpdates.get(p.id)! };
                    }
                    return p;
                });
            }

            updatedState.expenses = [newExpense, ...prev.expenses];
            return updatedState;
        });

        onClose();
    };


    return (
        <Modal title="Add New Expense" onClose={onClose}>
            <div className="form-group">
                <label>Expense Type</label>
                <select value={expenseType} onChange={e => setExpenseType(e.target.value as any)}>
                    <option value="General">General</option>
                    <option value="Salary">Salary Payment</option>
                    <option value="CanteenUsage">Canteen Usage (Stock Out)</option>
                </select>
            </div>
            <div className="form-group">
                <label>Date</label>
                <input type="date" value={date} onChange={e => setDate(e.target.value)} />
            </div>

            {expenseType === 'General' && (
                <>
                    <div className="form-group">
                        <label>Expense Title</label>
                        <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g., Electricity Bill" />
                    </div>
                    <div className="form-group">
                        <label>Amount</label>
                        <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00" />
                    </div>
                </>
            )}

            {expenseType === 'Salary' && (
                <>
                    <div className="form-group">
                        <label>Select Employee</label>
                        <SearchableSelect options={state.employees} value={selectedEmployee} onChange={(val) => setSelectedEmployee(val)} placeholder="Search employees..." />
                    </div>
                    {selectedEmployee && (
                         <div className="form-group">
                            <label>Amount (Salary)</label>
                            <input type="number" value={amount} onChange={e => setAmount(e.target.value)} />
                        </div>
                    )}
                </>
            )}
            
            {expenseType === 'CanteenUsage' && (
                 <div className="card" style={{ backgroundColor: '#f8f9fa' }}>
                    <h3 className="card-header-title" style={{ borderBottom: 'none', paddingBottom: 0 }}>Select Products Used</h3>
                     <div className="add-item-form">
                        <div className="form-group"><SearchableSelect options={state.products.filter(p=>p.stock > 0)} value={selectedProduct} onChange={(val) => setSelectedProduct(val)} placeholder="Select Product" /></div>
                        <div className="form-group" style={{ flexGrow: 0, width: '100px' }}><input type="number" value={quantity} onChange={e => setQuantity(e.target.value)} placeholder="Qty" /></div>
                        <button className="btn btn-secondary" onClick={handleAddCanteenItem}>Add</button>
                    </div>
                    <div className="table-container" style={{ marginTop: '15px' }}>
                        <table>
                            <tbody>
                                {items.map(item => {
                                    const product = state.products.find(p => p.id === item.productId);
                                    return <tr key={item.productId}>
                                        <td>{product?.name}</td>
                                        <td>{item.quantity} {product?.unit}</td>
                                        <td><button className="btn btn-icon btn-danger" onClick={() => handleRemoveCanteenItem(item.productId)}>&times;</button></td>
                                    </tr>
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
            
            <div className="form-group">
                <label>Category</label>
                <select value={category} onChange={e => setCategory(e.target.value)}>
                    <option value="">Select Category</option>
                    {state.expenseCategories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    <option value="add_new">-- Add New Category --</option>
                </select>
                {category === 'add_new' && (
                    <input type="text" value={newCategory} onChange={e => setNewCategory(e.target.value)} placeholder="New category name" style={{ marginTop: '10px' }} />
                )}
            </div>

            <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
                <button type="button" className="btn btn-primary" onClick={handleSubmit}>Save Expense</button>
            </div>
        </Modal>
    );
};

const ManageExpenses: React.FC = () => {
    const { state, formatCurrency } = useAppContext();
    const { expenses, employees } = state;
    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);

    const filteredExpenses = useMemo(() => {
        return expenses
            .filter(exp =>
                exp.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                exp.category.toLowerCase().includes(searchTerm.toLowerCase())
            )
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [expenses, searchTerm]);

    return (
        <div className="card">
            <h3 className="card-header-title">Manage Expenses</h3>
            <div className="toolbar">
                <div className="search-bar">
                    <input
                        type="text"
                        placeholder="Search by title or category..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                </div>
                <button className="btn btn-primary" onClick={() => setIsModalOpen(true)}>Add New Expense</button>
            </div>
            <div className="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Type</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredExpenses.length > 0 ? filteredExpenses.map(expense => {
                             const employee = expense.employeeId ? employees.find(e => e.id === expense.employeeId) : null;
                             return (
                                <tr key={expense.id}>
                                    <td>{formatDate(expense.date)}</td>
                                    <td>{expense.title} {employee ? `(${employee.name})` : ''}</td>
                                    <td>{expense.category}</td>
                                    <td>{expense.expenseType}</td>
                                    <td>{formatCurrency(expense.amount)}</td>
                                </tr>
                             )
                        }) : (
                            <tr><td colSpan={5} style={{ textAlign: 'center' }}>No expenses found.</td></tr>
                        )}
                    </tbody>
                </table>
            </div>
            {isModalOpen && <ExpenseFormModal onClose={() => setIsModalOpen(false)} />}
        </div>
    );
};


// --- Purchases Page and Modals ---

const PurchaseFormModal: React.FC<{
    onClose: () => void;
}> = ({ onClose }) => {
    const { state, setState, formatCurrency } = useAppContext();
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [supplier, setSupplier] = useState('');
    const [invoiceNumber, setInvoiceNumber] = useState('');
    const [notes, setNotes] = useState('');
    const [items, setItems] = useState<PurchaseItem[]>([]);
    
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
    const [quantity, setQuantity] = useState('');
    const [rate, setRate] = useState('');

    const handleAddItem = () => {
        if (!selectedProduct || !quantity || !rate) {
            alert('Please select a product and enter quantity and rate.');
            return;
        }
        const qty = parseFloat(quantity);
        const purchaseRate = parseFloat(rate);
        if (isNaN(qty) || qty <= 0 || isNaN(purchaseRate) || purchaseRate < 0) {
            alert('Please enter valid numbers for quantity and rate.');
            return;
        }

        const existingItemIndex = items.findIndex(i => i.productId === selectedProduct.id);
        if (existingItemIndex > -1) {
            const updatedItems = [...items];
            updatedItems[existingItemIndex].quantity += qty;
            setItems(updatedItems);
        } else {
            setItems([...items, { productId: selectedProduct.id, quantity: qty, purchaseRate }]);
        }

        setSelectedProduct(null);
        setQuantity('');
        setRate('');
    };

    const handleRemoveItem = (productId: string) => {
        setItems(items.filter(i => i.productId !== productId));
    };

    const totalAmount = useMemo(() => {
        return items.reduce((sum, item) => sum + item.quantity * item.purchaseRate, 0);
    }, [items]);

    const handleSubmit = () => {
        if (items.length === 0) {
            alert('Please add at least one item to the purchase.');
            return;
        }

        setState(prev => {
            const updatedProducts = prev.products.map(p => {
                const purchasedItem = items.find(item => item.productId === p.id);
                if (purchasedItem) {
                    return { ...p, stock: p.stock + purchasedItem.quantity };
                }
                return p;
            });

            const newPurchase: Purchase = {
                id: `PUR-${Date.now()}`,
                date: new Date(date).toISOString(),
                items,
                totalAmount,
                supplier,
                invoiceNumber,
                notes,
            };

            return {
                ...prev,
                products: updatedProducts,
                purchases: [newPurchase, ...prev.purchases],
            };
        });
        onClose();
    };

    useEffect(() => {
        if (selectedProduct) {
            setRate(String(selectedProduct.purchaseRate));
        }
    }, [selectedProduct]);

    return (
        <Modal title="Add New Purchase" onClose={onClose}>
            <div className="form-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
                <div className="form-group">
                    <label htmlFor="purchase-date">Purchase Date*</label>
                    <input type="date" id="purchase-date" value={date} onChange={e => setDate(e.target.value)} required />
                </div>
                <div className="form-group">
                    <label htmlFor="supplier-name">Supplier</label>
                    <input type="text" id="supplier-name" value={supplier} onChange={e => setSupplier(e.target.value)} placeholder="Supplier Name" />
                </div>
                <div className="form-group">
                    <label htmlFor="supplier-invoice">Supplier Invoice #</label>
                    <input type="text" id="supplier-invoice" value={invoiceNumber} onChange={e => setInvoiceNumber(e.target.value)} placeholder="Optional" />
                </div>
            </div>

            <div className="card" style={{ backgroundColor: '#f8f9fa', marginTop: '15px' }}>
                <h3 className="card-header-title" style={{ borderBottom: 'none', paddingBottom: 0 }}>Add Items</h3>
                <div className="add-item-form">
                    <div className="form-group">
                        <SearchableSelect options={state.products} value={selectedProduct} onChange={(product) => setSelectedProduct(product)} placeholder="Select Product" />
                    </div>
                    <div className="form-group" style={{ flexGrow: 0, width: '100px' }}>
                        <input type="number" value={quantity} onChange={e => setQuantity(e.target.value)} placeholder="Qty" disabled={!selectedProduct} />
                    </div>
                    <div className="form-group" style={{ flexGrow: 0, width: '100px' }}>
                        <input type="number" value={rate} onChange={e => setRate(e.target.value)} placeholder="Rate" disabled={!selectedProduct} />
                    </div>
                    <button className="btn btn-secondary" onClick={handleAddItem} disabled={!selectedProduct || !quantity || !rate}>Add</button>
                </div>
            </div>

            <div className="table-container" style={{ marginTop: '15px' }}>
                <table>
                    <thead>
                        <tr>
                            <th>Product</th><th>Qty</th><th>Rate</th><th style={{textAlign: 'right'}}>Subtotal</th><th></th>
                        </tr>
                    </thead>
                    <tbody>
                        {items.length > 0 ? items.map(item => {
                            const product = state.products.find(p => p.id === item.productId);
                            return (
                                <tr key={item.productId}>
                                    <td>{product?.name || 'N/A'}</td>
                                    <td>{item.quantity}</td>
                                    <td>{formatCurrency(item.purchaseRate)}</td>
                                    <td style={{textAlign: 'right'}}>{formatCurrency(item.quantity * item.purchaseRate)}</td>
                                    <td><button className="btn btn-icon btn-danger" onClick={() => handleRemoveItem(item.productId)}>&times;</button></td>
                                </tr>
                            );
                        }) : <tr><td colSpan={5} style={{textAlign: 'center'}}>No items added yet.</td></tr>}
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colSpan={3} style={{textAlign:'right'}}><strong>Total Amount</strong></td>
                            <td style={{textAlign: 'right'}}><strong>{formatCurrency(totalAmount)}</strong></td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <div className="form-group" style={{marginTop: '15px'}}>
                <label htmlFor="purchase-notes">Notes</label>
                <textarea id="purchase-notes" value={notes} onChange={e => setNotes(e.target.value)} rows={2}></textarea>
            </div>
            <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
                <button type="button" className="btn btn-primary" onClick={handleSubmit}>Save Purchase</button>
            </div>
        </Modal>
    );
};

const PurchaseDetailModal: React.FC<{
    purchase: Purchase;
    onClose: () => void;
}> = ({ purchase, onClose }) => {
    const { state, formatCurrency } = useAppContext();
    return (
        <Modal title={`Purchase Details - #${purchase.id}`} onClose={onClose}>
            <div className="invoice-detail-view">
                <section className="invoice-info">
                    <p><strong>Purchase ID:</strong> {purchase.id}</p>
                    <p><strong>Date:</strong> {new Date(purchase.date).toLocaleDateString()}</p>
                    {purchase.supplier && <p><strong>Supplier:</strong> {purchase.supplier}</p>}
                    {purchase.invoiceNumber && <p><strong>Supplier Invoice #:</strong> {purchase.invoiceNumber}</p>}
                </section>
                <table className="items-table">
                    <thead><tr><th>Item</th><th>Qty</th><th>Rate</th><th className="col-total">Subtotal</th></tr></thead>
                    <tbody>
                        {purchase.items.map(item => {
                            const product = state.products.find(p => p.id === item.productId);
                            return (
                                <tr key={item.productId}>
                                    <td>{product?.name || 'N/A'}</td>
                                    <td>{item.quantity} {product?.unit || ''}</td>
                                    <td>{formatCurrency(item.purchaseRate)}</td>
                                    <td className="col-total">{formatCurrency(item.quantity * item.purchaseRate)}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
                <section className="totals-section">
                    <div className="summary-row grand-total">
                        <span>TOTAL PURCHASE</span>
                        <span>{formatCurrency(purchase.totalAmount)}</span>
                    </div>
                </section>
                 {purchase.notes && (
                    <section className="payment-details">
                        <p><strong>Notes:</strong> {purchase.notes}</p>
                    </section>
                )}
            </div>
            <div className="modal-footer">
                <button className="btn btn-secondary" onClick={onClose}>Close</button>
            </div>
        </Modal>
    );
};

const Purchases: React.FC = () => {
    const { state, formatCurrency } = useAppContext();
    const [searchTerm, setSearchTerm] = useState('');
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [purchaseToView, setPurchaseToView] = useState<Purchase | null>(null);

    const filteredPurchases = useMemo(() => {
        return state.purchases
            .filter(p =>
                p.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                (p.supplier && p.supplier.toLowerCase().includes(searchTerm.toLowerCase()))
            )
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [state.purchases, searchTerm]);
    
    return (
        <div className="card">
            <h3 className="card-header-title">Manage Purchases</h3>
            <div className="toolbar">
                <div className="search-bar">
                    <input
                        type="text"
                        placeholder="Search by Purchase ID or Supplier..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                </div>
                <button className="btn btn-primary" onClick={() => setIsAddModalOpen(true)}>Add New Purchase</button>
            </div>
            <div className="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Purchase ID</th>
                            <th>Date</th>
                            <th>Supplier</th>
                            <th>Items</th>
                            <th>Total Amount</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredPurchases.length > 0 ? filteredPurchases.map(purchase => (
                            <tr key={purchase.id}>
                                <td>{purchase.id}</td>
                                <td>{new Date(purchase.date).toLocaleDateString()}</td>
                                <td>{purchase.supplier || 'N/A'}</td>
                                <td>{purchase.items.length}</td>
                                <td>{formatCurrency(purchase.totalAmount)}</td>
                                <td className="actions">
                                    <button className="btn btn-secondary" onClick={() => setPurchaseToView(purchase)}>View Details</button>
                                </td>
                            </tr>
                        )) : (
                            <tr><td colSpan={6} style={{ textAlign: 'center' }}>No purchases found.</td></tr>
                        )}
                    </tbody>
                </table>
            </div>
            {isAddModalOpen && <PurchaseFormModal onClose={() => setIsAddModalOpen(false)} />}
            {purchaseToView && <PurchaseDetailModal purchase={purchaseToView} onClose={() => setPurchaseToView(null)} />}
        </div>
    );
};

// --- Reports Page ---

const TodaysSalesReportViewer: React.FC<{onBack: () => void}> = ({onBack}) => {
    const { state, formatCurrency } = useAppContext();
    const { businessInfo, invoices, customers } = state;
    const reportContentRef = useRef<HTMLDivElement>(null);
    const reportTitle = `Today's Sales Report`;

    const reportData = useMemo(() => {
        const todayStr = new Date().toISOString().split('T')[0];
        
        const todaysInvoices = invoices.filter(inv => inv.date.startsWith(todayStr));
        const totalSales = todaysInvoices.reduce((sum, inv) => sum + inv.finalAmount, 0);

        const todaysPayments = invoices.flatMap(inv => inv.payments || [])
            .filter(p => p.date.startsWith(todayStr))
            .reduce((sum, p) => sum + p.amount, 0);

        const salesByCustomer = todaysInvoices.reduce((acc, inv) => {
            const customerId = inv.customerId || 'walk-in';
            if (!acc[customerId]) {
                const customer = customers.find(c => c.id === customerId) || WALK_IN_CUSTOMER;
                acc[customerId] = {
                    customerName: customer.name,
                    todaySales: 0,
                    totalBalance: getCustomerBalance(customerId, invoices),
                };
            }
            acc[customerId].todaySales += inv.finalAmount;
            return acc;
        }, {} as Record<string, { customerName: string; todaySales: number; totalBalance: number }>);
        
        return {
            summary: { totalSales, todaysPayments },
            todaysInvoices: todaysInvoices.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
            salesByCustomer: Object.values(salesByCustomer).sort((a,b) => b.todaySales - a.todaySales),
        };
    }, [invoices, customers]);

    const handlePrint = () => {
        printReport(reportTitle, reportContentRef.current, businessInfo);
    };

    return (
        <div className="card">
            <div className="toolbar" style={{ justifyContent: 'space-between' }}>
                <button className="btn btn-secondary" onClick={onBack}>&larr; Back to Reports Hub</button>
                <button className="btn btn-primary" onClick={handlePrint}>Print Report</button>
            </div>
           
            <div ref={reportContentRef} className="printable-report">
                 <div className="report-summary-grid">
                    <div className="summary-box"><span className="summary-box-label">Total Sales Today</span><span className="summary-box-value">{formatCurrency(reportData.summary.totalSales)}</span></div>
                    <div className="summary-box"><span className="summary-box-label">Cash Received Today</span><span className="summary-box-value profit">{formatCurrency(reportData.summary.todaysPayments)}</span></div>
                </div>

                <div className="report-section">
                    <h3>Sales by Customer (Today)</h3>
                    <div className="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Customer Name</th>
                                    <th>Today's Sales</th>
                                    <th>Total Outstanding Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                {reportData.salesByCustomer.length > 0 ? reportData.salesByCustomer.map(custData => (
                                    <tr key={custData.customerName}>
                                        <td>{custData.customerName}</td>
                                        <td>{formatCurrency(custData.todaySales)}</td>
                                        <td className={custData.totalBalance > 0 ? 'loss' : ''}>{formatCurrency(custData.totalBalance)}</td>
                                    </tr>
                                )) : (
                                    <tr><td colSpan={3} style={{textAlign: 'center'}}>No sales to show for any customer today.</td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>

                <div className="report-section">
                    <h3>Sales Details ({reportData.todaysInvoices.length} Invoices)</h3>
                    <div className="table-container">
                        <table>
                            <thead><tr><th>Invoice ID</th><th>Time</th><th>Customer</th><th>Amount</th><th>Status</th></tr></thead>
                            <tbody>
                                {reportData.todaysInvoices.length > 0 ? reportData.todaysInvoices.map(inv => {
                                    const customer = customers.find(c => c.id === inv.customerId);
                                    const paymentInfo = getInvoicePaymentInfo(inv);
                                    return <tr key={inv.id}>
                                        <td>{inv.id}</td>
                                        <td>{new Date(inv.date).toLocaleTimeString()}</td>
                                        <td>{customer?.name || 'Walk-in'}</td>
                                        <td>{formatCurrency(inv.finalAmount)}</td>
                                        <td><span className={`status-badge ${paymentInfo.status.className}`}>{paymentInfo.status.text}</span></td>
                                    </tr>;
                                }) : <tr><td colSpan={5} style={{textAlign: 'center'}}>No sales yet today.</td></tr>}
                            </tbody>
                             <tfoot><tr><td colSpan={3} style={{textAlign: 'right'}}><strong>Total</strong></td><td><strong>{formatCurrency(reportData.summary.totalSales)}</strong></td><td></td></tr></tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
};

const SalesReportViewer: React.FC<{onBack: () => void}> = ({onBack}) => {
    const { state, formatCurrency } = useAppContext();
    const { businessInfo, invoices, expenses, customers } = state;
    const reportContentRef = useRef<HTMLDivElement>(null);
    
    const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);
    const [startDate, setStartDate] = useState(todayStr);
    const [endDate, setEndDate] = useState(todayStr);
    const [reportTitle, setReportTitle] = useState(`Today's Sales & Profit Report`);

    const reportData = useMemo(() => {
        if (!startDate || !endDate) {
            return { summary: { totalSales: 0, cogs: 0, grossProfit: 0, totalExpenses: 0, netProfit: 0 }, filteredInvoices: [], filteredExpenses: [] };
        }

        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);

        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        
        const filteredInvoices = invoices.filter(inv => {
            const invDate = new Date(inv.date);
            return invDate >= start && invDate <= end;
        });

        const filteredExpenses = expenses.filter(exp => {
            const expDate = new Date(exp.date);
            return expDate >= start && expDate <= end;
        });
        
        const totalSales = filteredInvoices.reduce((sum, inv) => sum + inv.finalAmount, 0);
        const cogs = filteredInvoices.flatMap(inv => inv.items).reduce((sum, item) => sum + ((item.purchaseRate || 0) * item.quantity), 0);
        const grossProfit = totalSales - cogs;
        const totalExpenses = filteredExpenses.reduce((sum, exp) => sum + exp.amount, 0);
        const netProfit = grossProfit - totalExpenses;

        return {
            summary: { totalSales, cogs, grossProfit, totalExpenses, netProfit },
            filteredInvoices: filteredInvoices.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
            filteredExpenses: filteredExpenses.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        };
    }, [invoices, expenses, startDate, endDate]);

    const setDateRange = (period: 'today' | 'week' | 'month') => {
        const today = new Date();
        let start = new Date();
        let end = new Date();
        let title = '';

        if (period === 'today') {
            title = `Today's Sales & Profit Report`;
        } else if (period === 'week') {
            start = new Date(today.setDate(today.getDate() - today.getDay())); // Sunday
            end = new Date(start);
            end.setDate(end.getDate() + 6); // Saturday
            title = `This Week's Sales & Profit Report`;
        } else if (period === 'month') {
            start = new Date(today.getFullYear(), today.getMonth(), 1);
            end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
            title = `This Month's Sales & Profit Report`;
        }
        setStartDate(start.toISOString().split('T')[0]);
        setEndDate(end.toISOString().split('T')[0]);
        setReportTitle(title);
    };

    const handleCustomDateChange = () => {
         if (startDate && endDate) {
            const start = new Date(startDate).toLocaleDateString();
            const end = new Date(endDate).toLocaleDateString();
            setReportTitle(`Report from ${start} to ${end}`);
        }
    };
    
    useEffect(handleCustomDateChange, [startDate, endDate]);

    const handlePrint = () => {
        printReport(reportTitle, reportContentRef.current, businessInfo);
    };

    return (
        <div className="card">
            <div className="toolbar" style={{ justifyContent: 'space-between' }}>
                <button className="btn btn-secondary" onClick={onBack}>&larr; Back to Reports Hub</button>
                <button className="btn btn-primary" onClick={handlePrint}>Print Report</button>
            </div>
            <div className="toolbar">
                <div className="filter-control">
                    <button className="btn" onClick={() => setDateRange('today')}>Today</button>
                    <button className="btn" onClick={() => setDateRange('week')}>This Week</button>
                    <button className="btn" onClick={() => setDateRange('month')}>This Month</button>
                </div>
                <div className="filter-control">
                    <label>From:</label>
                    <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
                </div>
                <div className="filter-control">
                    <label>To:</label>
                    <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
                </div>
            </div>

            <div ref={reportContentRef} className="printable-report">
                <div className="report-summary-grid">
                    <div className="summary-box"><span className="summary-box-label">Total Sales</span><span className="summary-box-value">{formatCurrency(reportData.summary.totalSales)}</span></div>
                    <div className="summary-box"><span className="summary-box-label">Cost of Goods</span><span className="summary-box-value">{formatCurrency(reportData.summary.cogs)}</span></div>
                    <div className="summary-box"><span className="summary-box-label">Gross Profit</span><span className={`summary-box-value ${reportData.summary.grossProfit >= 0 ? 'profit' : 'loss'}`}>{formatCurrency(reportData.summary.grossProfit)}</span></div>
                    <div className="summary-box"><span className="summary-box-label">Total Expenses</span><span className="summary-box-value loss">{formatCurrency(reportData.summary.totalExpenses)}</span></div>
                    <div className="summary-box"><span className="summary-box-label">Net Profit / Loss</span><span className={`summary-box-value ${reportData.summary.netProfit >= 0 ? 'profit' : 'loss'}`}>{formatCurrency(reportData.summary.netProfit)}</span></div>
                </div>

                <div className="report-section">
                    <h3>Sales Details ({reportData.filteredInvoices.length} Invoices)</h3>
                    <div className="table-container">
                        <table>
                            <thead><tr><th>ID</th><th>Date</th><th>Customer</th><th>Amount</th></tr></thead>
                            <tbody>
                                {reportData.filteredInvoices.length > 0 ? reportData.filteredInvoices.map(inv => {
                                    const customer = customers.find(c => c.id === inv.customerId);
                                    return <tr key={inv.id}><td>{inv.id}</td><td>{formatDate(inv.date)}</td><td>{customer?.name || 'Walk-in'}</td><td>{formatCurrency(inv.finalAmount)}</td></tr>;
                                }) : <tr><td colSpan={4} style={{textAlign: 'center'}}>No sales in this period.</td></tr>}
                            </tbody>
                             <tfoot><tr><td colSpan={3} style={{textAlign: 'right'}}><strong>Total</strong></td><td><strong>{formatCurrency(reportData.summary.totalSales)}</strong></td></tr></tfoot>
                        </table>
                    </div>
                </div>

                 <div className="report-section">
                    <h3>Expense Details ({reportData.filteredExpenses.length} Entries)</h3>
                    <div className="table-container">
                        <table>
                            <thead><tr><th>Date</th><th>Title</th><th>Category</th><th>Amount</th></tr></thead>
                            <tbody>
                                {reportData.filteredExpenses.length > 0 ? reportData.filteredExpenses.map(exp => (
                                    <tr key={exp.id}><td>{formatDate(exp.date)}</td><td>{exp.title}</td><td>{exp.category}</td><td>{formatCurrency(exp.amount)}</td></tr>
                                )) : <tr><td colSpan={4} style={{textAlign: 'center'}}>No expenses in this period.</td></tr>}
                            </tbody>
                             <tfoot><tr><td colSpan={3} style={{textAlign: 'right'}}><strong>Total</strong></td><td><strong>{formatCurrency(reportData.summary.totalExpenses)}</strong></td></tr></tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
};

const ProductReportViewer: React.FC<{onBack: () => void}> = ({onBack}) => {
    const { state, formatCurrency } = useAppContext();
    const { businessInfo, invoices, products, purchases, expenses } = state;
    const reportContentRef = useRef<HTMLDivElement>(null);

    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
    const [searchTerm, setSearchTerm] = useState('');

    const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);
    const [startDate, setStartDate] = useState(todayStr);
    const [endDate, setEndDate] = useState(todayStr);

    const filteredProductList = useMemo(() =>
        products.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()))
        .sort((a, b) => a.name.localeCompare(b.name)),
        [products, searchTerm]
    );

    const ledgerData = useMemo(() => {
        if (!selectedProduct || !startDate || !endDate) return null;

        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);

        // 1. Calculate Opening Stock
        let openingStock = 0;
        purchases.forEach(p => p.items.forEach(i => {
            if (i.productId === selectedProduct.id && new Date(p.date) < start) openingStock += i.quantity;
        }));
        invoices.forEach(inv => inv.items.forEach(i => {
            if (i.productId === selectedProduct.id && new Date(inv.date) < start) openingStock -= i.quantity;
        }));
        expenses.forEach(exp => {
            if (exp.expenseType === 'CanteenUsage' && new Date(exp.date) < start) {
                exp.items?.forEach(i => {
                    if (i.productId === selectedProduct.id) openingStock -= i.quantity;
                });
            }
        });

        // 2. Gather transactions within the period
        const transactions: {date: string, type: string, details: string, qtyIn: number, qtyOut: number}[] = [];
        purchases.forEach(p => {
            const pDate = new Date(p.date);
            if (pDate >= start && pDate <= end) {
                p.items.forEach(i => {
                    if (i.productId === selectedProduct.id) {
                        transactions.push({ date: p.date, type: 'Purchase', details: `ID: ${p.id}`, qtyIn: i.quantity, qtyOut: 0 });
                    }
                });
            }
        });
        invoices.forEach(inv => {
            const iDate = new Date(inv.date);
            if (iDate >= start && iDate <= end) {
                inv.items.forEach(i => {
                    if (i.productId === selectedProduct.id) {
                        transactions.push({ date: inv.date, type: 'Sale', details: `Invoice: ${inv.id}`, qtyIn: 0, qtyOut: i.quantity });
                    }
                });
            }
        });
        expenses.forEach(exp => {
            if (exp.expenseType === 'CanteenUsage') {
                 const eDate = new Date(exp.date);
                if (eDate >= start && eDate <= end) {
                    exp.items?.forEach(i => {
                        if (i.productId === selectedProduct.id) {
                            transactions.push({ date: exp.date, type: 'Canteen Usage', details: `Expense: ${exp.id}`, qtyIn: 0, qtyOut: i.quantity });
                        }
                    });
                }
            }
        });

        transactions.sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());

        let runningStock = openingStock;
        const ledgerEntries = transactions.map(t => {
            runningStock += t.qtyIn - t.qtyOut;
            return {...t, balance: runningStock };
        });

        return { openingStock, ledgerEntries, closingStock: runningStock };

    }, [selectedProduct, startDate, endDate, invoices, purchases, expenses]);


    const handlePrint = () => {
        const title = selectedProduct ? `Stock Ledger for ${selectedProduct.name}` : 'Product Performance Report';
        printReport(title, reportContentRef.current, businessInfo);
    };

    if (!selectedProduct) {
        return (
            <div className="card">
                <div className="toolbar" style={{ justifyContent: 'space-between' }}>
                    <button className="btn btn-secondary" onClick={onBack}>&larr; Back to Reports Hub</button>
                </div>
                <div className="toolbar">
                     <div className="search-bar">
                        <input
                            type="text"
                            placeholder="Search for a product..."
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>
                <div className="table-container">
                    <table>
                        <thead><tr><th>Product Name</th><th>Category</th><th>Current Stock</th><th>Actions</th></tr></thead>
                        <tbody>
                            {filteredProductList.length > 0 ? filteredProductList.map(product => (
                                <tr key={product.id}>
                                    <td>{product.name}</td>
                                    <td>{product.category}</td>
                                    <td>{product.stock} {product.unit}</td>
                                    <td><button className="btn btn-primary" onClick={() => setSelectedProduct(product)}>View Ledger</button></td>
                                </tr>
                            )) : <tr><td colSpan={4} style={{textAlign: 'center'}}>No products found.</td></tr>}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }

    return (
        <div className="card">
             <div className="toolbar" style={{ justifyContent: 'space-between' }}>
                <div>
                    <button className="btn btn-secondary" onClick={() => setSelectedProduct(null)}>&larr; Back to Product List</button>
                </div>
                <button className="btn btn-primary" onClick={handlePrint}>Print Ledger</button>
            </div>
             <div className="toolbar">
                 <div className="filter-control">
                    <label>From:</label>
                    <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
                </div>
                <div className="filter-control">
                    <label>To:</label>
                    <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
                </div>
            </div>
            <div ref={reportContentRef}>
                 <div className="report-section">
                    <h3>Stock Ledger: {selectedProduct.name}</h3>
                    <div className="table-container">
                        <table>
                            <thead>
                                <tr><th>Date</th><th>Transaction Type</th><th>Details</th><th>In</th><th>Out</th><th>Balance</th></tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colSpan={5}><strong>Opening Stock</strong></td>
                                    <td><strong>{ledgerData?.openingStock}</strong></td>
                                </tr>
                                {ledgerData && ledgerData.ledgerEntries.length > 0 ? ledgerData.ledgerEntries.map((entry, index) => (
                                    <tr key={index}>
                                        <td>{new Date(entry.date).toLocaleDateString()}</td>
                                        <td>{entry.type}</td>
                                        <td>{entry.details}</td>
                                        <td>{entry.qtyIn > 0 ? entry.qtyIn : '-'}</td>
                                        <td>{entry.qtyOut > 0 ? entry.qtyOut : '-'}</td>
                                        <td>{entry.balance}</td>
                                    </tr>
                                )) : <tr><td colSpan={6} style={{textAlign: 'center'}}>No transactions in this period.</td></tr>}
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colSpan={5}><strong>Closing Stock</strong></td>
                                    <td><strong>{ledgerData?.closingStock}</strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                 </div>
            </div>
        </div>
    );
};

const CustomerReportViewer: React.FC<{onBack: () => void}> = ({onBack}) => {
    const { state, formatCurrency } = useAppContext();
    const { businessInfo, invoices, customers } = state;
    const reportContentRef = useRef<HTMLDivElement>(null);

    const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
    const [searchTerm, setSearchTerm] = useState('');

    const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);
    const [startDate, setStartDate] = useState(todayStr);
    const [endDate, setEndDate] = useState(todayStr);

    const filteredCustomerList = useMemo(() =>
        [...customers, WALK_IN_CUSTOMER]
            .filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()))
            .map(c => ({...c, balance: getCustomerBalance(c.id, invoices)}))
            .sort((a, b) => a.name.localeCompare(b.name)),
        [customers, invoices, searchTerm]
    );

    const ledgerData = useMemo(() => {
        if (!selectedCustomer || !startDate || !endDate) return null;

        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);

        const customerId = selectedCustomer.id === 'walk-in' ? undefined : selectedCustomer.id;

        // 1. Calculate Opening Balance
        let openingBalance = 0;
        invoices.forEach(inv => {
            if ((inv.customerId || undefined) === customerId && new Date(inv.date) < start) {
                openingBalance += inv.finalAmount;
                (inv.payments || []).forEach(p => {
                    if (new Date(p.date) < start) {
                        openingBalance -= p.amount;
                    }
                });
            }
        });

        // 2. Gather transactions within the period
        const transactions: {date: string, details: string, debit: number, credit: number}[] = [];
        invoices.forEach(inv => {
            if ((inv.customerId || undefined) === customerId) {
                const iDate = new Date(inv.date);
                if (iDate >= start && iDate <= end) {
                    transactions.push({ date: inv.date, details: `Invoice #${inv.id}`, debit: inv.finalAmount, credit: 0 });
                }
                (inv.payments || []).forEach(p => {
                    const pDate = new Date(p.date);
                    if (pDate >= start && pDate <= end) {
                        transactions.push({ date: p.date, details: `Payment for #${inv.id}`, debit: 0, credit: p.amount });
                    }
                });
            }
        });

        transactions.sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());

        let runningBalance = openingBalance;
        const ledgerEntries = transactions.map(t => {
            runningBalance += t.debit - t.credit;
            return {...t, balance: runningBalance };
        });

        return { openingBalance, ledgerEntries, closingBalance: runningBalance };

    }, [selectedCustomer, startDate, endDate, invoices]);

    const handlePrint = () => {
        const title = selectedCustomer ? `Ledger for ${selectedCustomer.name}` : 'Customer Report';
        printReport(title, reportContentRef.current, businessInfo);
    };

    if (!selectedCustomer) {
        return (
            <div className="card">
                 <div className="toolbar" style={{ justifyContent: 'space-between' }}>
                    <button className="btn btn-secondary" onClick={onBack}>&larr; Back to Reports Hub</button>
                </div>
                <div className="toolbar">
                    <div className="search-bar">
                        <input
                            type="text"
                            placeholder="Search for a customer..."
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>
                <div className="table-container">
                    <table>
                        <thead><tr><th>Customer Name</th><th>Mobile</th><th>Balance Due</th><th>Actions</th></tr></thead>
                        <tbody>
                            {filteredCustomerList.map(customer => (
                                <tr key={customer.id}>
                                    <td>{customer.name}</td>
                                    <td>{customer.mobile}</td>
                                    <td className={customer.balance > 0 ? 'loss' : ''}>{formatCurrency(customer.balance)}</td>
                                    <td><button className="btn btn-primary" onClick={() => setSelectedCustomer(customer)}>View Ledger</button></td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }
    
    return (
        <div className="card">
             <div className="toolbar" style={{ justifyContent: 'space-between' }}>
                <div>
                    <button className="btn btn-secondary" onClick={() => setSelectedCustomer(null)}>&larr; Back to Customer List</button>
                </div>
                <button className="btn btn-primary" onClick={handlePrint}>Print Ledger</button>
            </div>
            <div className="toolbar">
                 <div className="filter-control">
                    <label>From:</label>
                    <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
                </div>
                <div className="filter-control">
                    <label>To:</label>
                    <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
                </div>
            </div>
             <div ref={reportContentRef}>
                <div className="report-section">
                    <h3>Customer Ledger: {selectedCustomer.name}</h3>
                     <div className="table-container">
                        <table>
                            <thead><tr><th>Date</th><th>Details</th><th>Debit</th><th>Credit</th><th>Balance</th></tr></thead>
                            <tbody>
                                <tr>
                                    <td colSpan={4}><strong>Opening Balance</strong></td>
                                    <td><strong>{formatCurrency(ledgerData?.openingBalance || 0)}</strong></td>
                                </tr>
                                {ledgerData && ledgerData.ledgerEntries.length > 0 ? ledgerData.ledgerEntries.map((entry, index) => (
                                    <tr key={index}>
                                        <td>{new Date(entry.date).toLocaleDateString()}</td>
                                        <td>{entry.details}</td>
                                        <td>{entry.debit > 0 ? formatCurrency(entry.debit) : '-'}</td>
                                        <td>{entry.credit > 0 ? formatCurrency(entry.credit) : '-'}</td>
                                        <td>{formatCurrency(entry.balance)}</td>
                                    </tr>
                                )) : <tr><td colSpan={5} style={{textAlign: 'center'}}>No transactions in this period.</td></tr>}
                            </tbody>
                             <tfoot>
                                <tr>
                                    <td colSpan={4}><strong>Closing Balance</strong></td>
                                    <td><strong>{formatCurrency(ledgerData?.closingBalance || 0)}</strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
};

const ReceivablesReportViewer: React.FC<{onBack: () => void}> = ({ onBack }) => {
    const { state, formatCurrency } = useAppContext();
    const { businessInfo, invoices, customers } = state;
    const reportContentRef = useRef<HTMLDivElement>(null);

    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
    
    const [startDate, setStartDate] = useState(firstDayOfMonth);
    const [endDate, setEndDate] = useState(todayStr);
    const reportTitle = `Accounts Receivable Report (${formatDate(startDate)} to ${formatDate(endDate)})`;

    const reportData = useMemo(() => {
        if (!startDate || !endDate) {
            return { customerDebts: [], totalOutstanding: 0 };
        }
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);

        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);

        const outstandingInvoices = invoices.filter(inv => {
            const paymentInfo = getInvoicePaymentInfo(inv);
            const invDate = new Date(inv.date);
            return paymentInfo.balanceDue > 0.01 && invDate >= start && invDate <= end;
        });

        const debtsByCustomer = outstandingInvoices.reduce((acc, inv) => {
            const customerId = inv.customerId || 'walk-in';
            if (!acc[customerId]) {
                const customer = customers.find(c => c.id === customerId) || WALK_IN_CUSTOMER;
                acc[customerId] = {
                    customerName: customer.name,
                    mobile: customer.mobile,
                    invoices: [],
                    totalDue: 0,
                };
            }
            const invBalance = getInvoicePaymentInfo(inv).balanceDue;
            acc[customerId].invoices.push({...inv, balanceDue: invBalance});
            acc[customerId].totalDue += invBalance;
            return acc;
        }, {} as Record<string, { customerName: string; mobile: string; invoices: (Invoice & {balanceDue: number})[]; totalDue: number }>);
        
        const customerDebts = Object.values(debtsByCustomer).sort((a,b) => b.totalDue - a.totalDue);
        const totalOutstanding = customerDebts.reduce((sum, cust) => sum + cust.totalDue, 0);

        return { customerDebts, totalOutstanding };
    }, [invoices, customers, startDate, endDate]);

    const handlePrint = () => {
        printReport(reportTitle, reportContentRef.current, businessInfo);
    };

    return (
        <div className="card">
            <div className="toolbar" style={{ justifyContent: 'space-between' }}>
                <button className="btn btn-secondary" onClick={onBack}>&larr; Back to Reports Hub</button>
                <button className="btn btn-primary" onClick={handlePrint}>Print Report</button>
            </div>
            <div className="toolbar">
                <div className="filter-control">
                    <label>From:</label>
                    <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
                </div>
                <div className="filter-control">
                    <label>To:</label>
                    <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
                </div>
            </div>

            <div ref={reportContentRef} className="printable-report">
                <div className="report-section">
                    <h3>Outstanding Customer Balances</h3>
                    <div className="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Customer</th>
                                    <th>Invoice #</th>
                                    <th>Date</th>
                                    <th>Total Amount</th>
                                    <th>Outstanding Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                {reportData.customerDebts.length > 0 ? (
                                    reportData.customerDebts.map(cust => (
                                        <React.Fragment key={cust.customerName}>
                                            <tr className="receivables-customer-row">
                                                <td colSpan={4}>{cust.customerName} {cust.mobile && `(${cust.mobile})`}</td>
                                                <td>{formatCurrency(cust.totalDue)}</td>
                                            </tr>
                                            {cust.invoices.map(inv => (
                                                <tr key={inv.id} className="receivables-invoice-row">
                                                    <td></td>
                                                    <td>{inv.id}</td>
                                                    <td>{formatDate(inv.date)}</td>
                                                    <td>{formatCurrency(inv.finalAmount)}</td>
                                                    <td className="loss">{formatCurrency(inv.balanceDue)}</td>
                                                </tr>
                                            ))}
                                        </React.Fragment>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan={5} style={{ textAlign: 'center' }}>No outstanding receivables found for the selected period.</td>
                                    </tr>
                                )}
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colSpan={4} style={{ textAlign: 'right' }}><strong>Total Outstanding</strong></td>
                                    <td><strong>{formatCurrency(reportData.totalOutstanding)}</strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
};


const Reports: React.FC = () => {
    const [view, setView] = useState<'hub' | 'sales' | 'products' | 'customers' | 'today_sales' | 'receivables'>('hub');

    if (view === 'sales') {
        return <SalesReportViewer onBack={() => setView('hub')} />;
    }

    if (view === 'products') {
        return <ProductReportViewer onBack={() => setView('hub')} />;
    }
    
    if (view === 'customers') {
        return <CustomerReportViewer onBack={() => setView('hub')} />;
    }

    if (view === 'today_sales') {
        return <TodaysSalesReportViewer onBack={() => setView('hub')} />;
    }
    
    if (view === 'receivables') {
        return <ReceivablesReportViewer onBack={() => setView('hub')} />;
    }

    return (
        <div className="card">
            <h3 className="card-header-title">Reports Center</h3>
            <p style={{marginBottom: '20px'}}>Select a report to view analytics for your business.</p>
            <div className="reports-hub-grid">
                 <div className="action-button report-hub-card" onClick={() => setView('today_sales')}>
                    <div className="action-button-icon">☀️</div>
                    <div className="report-card-text">
                        <span className="report-card-title">Today's Sales Report</span>
                        <span className="report-card-description">A quick summary of sales made today.</span>
                    </div>
                </div>
                <div className="action-button report-hub-card" onClick={() => setView('sales')}>
                    <div className="action-button-icon">📈</div>
                    <div className="report-card-text">
                        <span className="report-card-title">Sales & Profit Report</span>
                        <span className="report-card-description">View sales, costs, and profits for specific periods.</span>
                    </div>
                </div>
                <div className="action-button report-hub-card" onClick={() => setView('products')}>
                    <div className="action-button-icon">🍔</div>
                    <div className="report-card-text">
                        <span className="report-card-title">Product Ledger</span>
                        <span className="report-card-description">Analyze stock movements for each product.</span>
                    </div>
                </div>
                 <div className="action-button report-hub-card" onClick={() => setView('customers')}>
                    <div className="action-button-icon">👥</div>
                    <div className="report-card-text">
                        <span className="report-card-title">Customer Ledger</span>
                        <span className="report-card-description">Track sales and payments for each customer.</span>
                    </div>
                </div>
                <div className="action-button report-hub-card" onClick={() => setView('receivables')}>
                    <div className="action-button-icon">💸</div>
                    <div className="report-card-text">
                        <span className="report-card-title">Accounts Receivable</span>
                        <span className="report-card-description">View all unpaid customer bills.</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

const Settings: React.FC = () => {
    const { state, setState } = useAppContext();
    const [businessInfo, setBusinessInfo] = useState<BusinessInfo>(state.businessInfo);
    const restoreInputRef = useRef<HTMLInputElement>(null);

    // Sync local state if global state changes (e.g., after a restore)
    useEffect(() => {
        setBusinessInfo(state.businessInfo);
    }, [state.businessInfo]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setBusinessInfo(prev => ({ ...prev, [name]: value }));
    };

    const handleLogoChange = (base64: string) => {
        setBusinessInfo(prev => ({ ...prev, logo: base64 }));
    };

    const handleQRChange = (base64: string) => {
        setBusinessInfo(prev => ({ ...prev, customQRImage: base64 }));
    };

    const handleSaveChanges = () => {
        setState(prev => ({ ...prev, businessInfo }));
        alert("Settings saved successfully!");
    };
    
    const handleBackupNow = async () => {
        const dataToBackup = { ...state, businessInfo };
        try {
            const timestamp = new Date().toISOString().replace(/:/g, '-').split('.')[0];
            const fileName = `canteen-pos-backup-${timestamp}.json`;
            const dataStr = JSON.stringify(dataToBackup, null, 2);
            const blob = new Blob([dataStr], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            const link = document.createElement('a');
            link.href = url;
            link.download = fileName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);

            alert('Backup file is being downloaded.');
        } catch (error) {
            console.error("Web backup failed:", error);
            alert(`Backup failed: ${(error as Error).message}`);
        }
    };

    const handleRestoreFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) {
            return;
        }

        if (!window.confirm("Restoring from a backup will overwrite ALL current data (products, sales, settings, etc.). This action cannot be undone. Are you sure you want to proceed?")) {
            if (restoreInputRef.current) {
                restoreInputRef.current.value = "";
            }
            return;
        }

        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const result = event.target?.result;
                if (typeof result !== 'string') {
                    throw new Error("Could not read file content.");
                }
                let restoredState = JSON.parse(result);
                // Basic validation to check if it's a valid data file
                if (restoredState.businessInfo && Array.isArray(restoredState.products)) {
                    // Run migrations on restored data to ensure compatibility
                    restoredState = migratePurchases(migrateInvoices(restoredState));

                    // Immediately save the restored data to disk to ensure persistence
                    if (window.electronAPI) {
                        console.log("Restored data. Saving to disk immediately.");
                        window.electronAPI.saveDataSync(restoredState);
                    }
                    
                    // Then update the state to re-render the app with the new data
                    setState(restoredState);

                    alert("Data has been restored successfully. The application is now using the restored data.");
                } else {
                    throw new Error("File does not appear to be a valid backup file.");
                }
            } catch (err) {
                 alert(`Failed to restore data. The file might be corrupted or in an incorrect format. Error: ${(err as Error).message}`);
            } finally {
                if (restoreInputRef.current) {
                    restoreInputRef.current.value = "";
                }
            }
        };
        reader.onerror = () => {
             alert(`Failed to read the backup file: ${reader.error}`);
             if (restoreInputRef.current) {
                restoreInputRef.current.value = "";
             }
        };
        reader.readAsText(file);
    };

    return (
        <div className="settings-page">
            <h1 className="header">Application Settings</h1>
            
            <div className="settings-grid">
                <div className="card settings-card">
                    <h3 className="card-header-title">Business Information</h3>
                    <div className="form-group">
                        <label>Business Name</label>
                        <input type="text" name="name" value={businessInfo.name} onChange={handleInputChange} />
                    </div>
                    <div className="form-group">
                        <label>Business Address (for receipts)</label>
                        <textarea name="address" value={businessInfo.address || ''} onChange={handleInputChange} rows={3} placeholder="Your Company Name&#10;Street Address&#10;City, Postal Code"></textarea>
                    </div>
                    <ImageUpload label="Business Logo (for receipts)" currentImage={businessInfo.logo} onImageChange={handleLogoChange} />
                    <p className="help-text">For best results on thermal printers, use a simple, black and white logo. Recommended size: under 200x200 pixels.</p>
                </div>

                <div className="card settings-card">
                    <h3 className="card-header-title">Payment QR Code</h3>
                    <div className="form-group">
                        <label>Payment Number/ID</label>
                        <input type="text" name="paymentNumber" value={businessInfo.paymentNumber || ''} onChange={handleInputChange} placeholder="e.g., your UPI ID, phone number" />
                        <p className="help-text" style={{padding: '5px 10px', marginTop: '5px'}}>A QR code will be auto-generated from this on receipts.</p>
                    </div>
                    <ImageUpload label="Or, Upload Custom QR Image" currentImage={businessInfo.customQRImage || ''} onImageChange={handleQRChange} />
                    <p className="help-text">If you upload a custom QR image, it will be used instead of the auto-generated one.</p>
                </div>

                 <div className="card settings-card">
                    <h3 className="card-header-title">Data Backup & Restore</h3>
                    <div className="form-group">
                         <label>Manual Actions</label>
                         <div className="actions" style={{gap: '10px', display: 'flex', flexWrap: 'wrap'}}>
                            <button 
                                className="btn btn-primary" 
                                onClick={handleBackupNow}
                                title="Download a backup file of your current data.">
                                Backup Now
                            </button>
                            <button 
                                className="btn btn-danger" 
                                onClick={() => restoreInputRef.current?.click()}
                                title="Restore data from a backup file. This will overwrite all current data.">
                                Restore from Backup
                            </button>
                            <input
                                type="file"
                                ref={restoreInputRef}
                                onChange={handleRestoreFileSelect}
                                accept=".json"
                                style={{ display: 'none' }}
                            />
                         </div>
                         <p className="help-text">'Backup Now' downloads a local copy of all your data. 'Restore' lets you upload that file to recover your data, but it will overwrite everything currently in the app.</p>
                    </div>
                </div>
            </div>

            <div className="modal-footer" style={{ justifyContent: 'center', marginTop: '20px', borderTop: '1px solid var(--border-color)', paddingTop: '20px' }}>
                <button className="btn btn-primary" style={{ padding: '12px 40px', fontSize: '1.1rem' }} onClick={handleSaveChanges}>Save All Settings</button>
            </div>
        </div>
    );
};


// --- MAIN APP COMPONENT ---

const App: React.FC = () => {
    const [state, setState] = useState<AppState | null>(null);
    const [activePage, setActivePage] = useState<string>('dashboard');
    const [isSidebarOpen, setSidebarOpen] = useState(false);

    useEffect(() => {
        const LOCAL_STORAGE_KEY = 'canteen-pos-data';
        const defaultState: AppState = {
            businessInfo: { name: 'Canteen POS', logo: '' },
            customers: [],
            employees: [],
            products: [],
            invoices: [],
            purchases: [],
            expenses: [],
            expenseCategories: ['Food', 'Utilities', 'Salary', 'Maintenance', 'Rent']
        };

        const loadInitialData = async () => {
            let data: AppState | null = null;
            
            // Try Electron API first for desktop persistence
            if (window.electronAPI) {
                console.log("Running in Electron. Attempting to load data from file.");
                try {
                    data = await window.electronAPI.loadData();
                } catch (error) {
                    console.error("Electron: Failed to load data.", error);
                    alert("A problem occurred while loading your data via Electron. The application might start with a blank state.");
                }
            } else { // Fallback to localStorage for web browser persistence
                 console.log("Not in Electron. Attempting to load data from localStorage.");
                 try {
                    const savedData = localStorage.getItem(LOCAL_STORAGE_KEY);
                    if (savedData) {
                        data = JSON.parse(savedData);
                    }
                } catch (error) {
                    console.error("LocalStorage: Failed to load data. Starting fresh.", error);
                    alert("A problem occurred while loading your data from the browser's local storage. The application will start with a blank state.");
                }
            }

            if (data) {
                // If data exists, migrate it to ensure it's up-to-date with the latest structure.
                console.log("Data found, applying migrations if necessary.");
                data = migratePurchases(migrateInvoices(data));
                setState(data);
            } else {
                // If no data is found anywhere, start with a fresh, default state.
                console.log("No saved data found. Initializing with default state.");
                setState(defaultState);
            }
        };

        loadInitialData();
    }, []);

    // Auto-save data on change with a debounce
    useEffect(() => {
        const LOCAL_STORAGE_KEY = 'canteen-pos-data';
        
        // Don't save if state is not initialized yet. This prevents overwriting saved data with null on startup.
        if (!state) {
            return;
        }

        const timer = setTimeout(() => {
            // In Electron, use the dedicated synchronous file save API.
            if (window.electronAPI) {
                console.log("Auto-saving application state to file...");
                window.electronAPI.saveDataSync(state);
            } else {
                // In a web browser, save to localStorage.
                try {
                    console.log("Auto-saving application state to localStorage...");
                    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(state));
                } catch (error) {
                    console.error("LocalStorage: Failed to save data.", error);
                    // This can happen if storage is full.
                    alert("Could not save application data to browser storage. Your recent changes may be lost on refresh. Please check your browser settings.");
                }
            }
        }, 1500); // Save 1.5 seconds after the last state change.

        return () => {
            clearTimeout(timer);
        };
    }, [state]); // Dependency on state ensures this runs on every state update.


    if (!state) {
        return <div className="loading-screen">Loading Canteen Data...</div>;
    }

    const renderActivePage = () => {
        switch (activePage) {
            case 'dashboard': return <Dashboard />;
            case 'newSale': return <NewSale />;
            case 'products': return <ManageProducts />;
            case 'customers': return <ManageCustomers />;
            case 'employees': return <ManageEmployees />;
            case 'expenses': return <ManageExpenses />;
            case 'invoices': return <Invoices />;
            case 'purchases': return <Purchases />;
            case 'reports': return <Reports />;
            case 'settings': return <Settings />;
            default: return <Dashboard />;
        }
    };

    return (
        <AppContext.Provider value={{ state, setState, activePage, setActivePage, formatCurrency }}>
            <div className="top-bar">
                <button className="hamburger" onClick={() => setSidebarOpen(!isSidebarOpen)}>&#9776;</button>
                <h2>{state.businessInfo.name}</h2>
                <div></div>
            </div>
            <div className="main-container">
                <nav className={`sidebar ${isSidebarOpen ? 'open' : ''}`}>
                    <div className="sidebar-header">
                        <h2><span>🛍️</span> {state.businessInfo.name}</h2>
                    </div>
                    <ul className="sidebar-nav">
                         <NavItem icon="🏠" text="Dashboard" page="dashboard" />
                         <NavItem icon="🛒" text="New Sale" page="newSale" />
                         <NavItem icon="🧾" text="Invoices" page="invoices" />
                         <hr style={{margin: '10px 20px', borderColor: 'rgba(255,255,255,0.1)'}} />
                         <NavItem icon="🍔" text="Products" page="products" />
                         <NavItem icon="📦" text="Purchases" page="purchases" />
                         <NavItem icon="💸" text="Expenses" page="expenses" />
                         <hr style={{margin: '10px 20px', borderColor: 'rgba(255,255,255,0.1)'}} />
                         <NavItem icon="👥" text="Customers" page="customers" />
                         <NavItem icon="👨‍🍳" text="Employees" page="employees" />
                         <hr style={{margin: '10px 20px', borderColor: 'rgba(255,255,255,0.1)'}} />
                         <NavItem icon="📊" text="Reports" page="reports" />
                         <NavItem icon="⚙️" text="Settings" page="settings" />
                    </ul>
                     <div className="sidebar-footer">
                        <p>Canteen POS v2.2.0</p>
                        <p style={{fontSize: '0.75rem', color: '#bdc3c7', marginTop: '8px', lineHeight: 1.4}}>
                            Developed by Mr Nadeem Ch<br />03435601381
                        </p>
                    </div>
                </nav>
                <main className="content">
                    {renderActivePage()}
                </main>
            </div>
        </AppContext.Provider>
    );
};

const root = createRoot(document.getElementById('root')!);
root.render(<App />);